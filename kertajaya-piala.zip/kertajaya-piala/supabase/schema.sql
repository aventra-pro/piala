-- =====================================================================
--  KERTAJAYA PIALA ERP — skema database Supabase
--  Jalankan SEKALI di Supabase > SQL Editor (seluruh file).
--  Prinsip: stok & uang hanya berubah lewat fungsi (RPC) yang
--  meninggalkan dokumen + jejak. Tidak ada DELETE pada data transaksi.
-- =====================================================================
create extension if not exists pgcrypto;

-- ---------- utilitas waktu ----------
create or replace function public.today_jkt() returns date
language sql stable as $$ select (now() at time zone 'Asia/Jakarta')::date $$;

-- ---------- jabatan ----------
create table if not exists public.roles (
  code text primary key,
  name text not null,
  division text not null,
  is_global boolean not null default false,        -- boleh melihat semua cabang
  discount_limit_pct numeric(5,2) not null default 0,
  sort int not null default 0
);

insert into public.roles(code,name,division,is_global,discount_limit_pct,sort) values
 ('owner','Direktur Utama / Owner','Manajemen Puncak',true,100,1),
 ('area_manager','Manajer Operasional Wilayah','Manajemen Puncak',true,30,2),
 ('warehouse_manager','Manajer Gudang Pusat','Gudang & Persediaan',false,0,10),
 ('inventory_admin','Staf Admin Gudang','Gudang & Persediaan',false,0,11),
 ('purchasing','Staf Pembelian','Gudang & Persediaan',false,0,12),
 ('production_head','Kepala Produksi','Produksi',false,0,20),
 ('operator','Operator Grafir / Laser / Perakitan','Produksi',false,0,21),
 ('designer','Staf Desain','Produksi',false,0,22),
 ('branch_head','Kepala Cabang','Penjualan',false,15,30),
 ('cashier','Kasir / Admin Toko','Penjualan',false,5,31),
 ('online_admin','Admin Online & CS','Penjualan',false,5,32),
 ('logistics','Admin Logistik / Pengiriman','Logistik, Retur & QC',false,0,40),
 ('qc_return','Staf QC & Retur','Logistik, Retur & QC',false,0,41),
 ('finance_manager','Manajer Keuangan','Keuangan',true,20,50),
 ('accountant','Staf Akuntansi','Keuangan',true,0,51),
 ('payment_verifier','Verifikator Pembayaran','Keuangan',true,0,52)
on conflict (code) do nothing;

-- rangkap jabatan yang dilarang (pemisahan tugas)
create table if not exists public.sod_conflicts (
  role_a text references public.roles, role_b text references public.roles,
  reason text not null, primary key (role_a, role_b)
);
insert into public.sod_conflicts values
 ('purchasing','inventory_admin','Staf Pembelian tidak boleh merangkap penerima barang'),
 ('qc_return','online_admin','Penerima barang retur tidak boleh merangkap pemroses retur marketplace'),
 ('payment_verifier','cashier','Verifikator pembayaran tidak boleh merangkap penginput pesanan (kasir)'),
 ('payment_verifier','online_admin','Verifikator pembayaran tidak boleh merangkap penginput pesanan (admin online)'),
 ('payment_verifier','branch_head','Verifikator pembayaran tidak boleh merangkap kepala cabang yang menginput pesanan')
on conflict do nothing;

-- ---------- cabang & lokasi stok ----------
create table if not exists public.branches (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  kind text not null default 'branch' check (kind in ('hq','warehouse','branch','production')),
  address text, phone text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.stock_locations (
  id uuid primary key default gen_random_uuid(),
  branch_id uuid references public.branches,
  code text not null unique,
  name text not null,
  kind text not null check (kind in ('main','in_transit','quarantine','scrap','offcut')),
  active boolean not null default true
);

insert into public.stock_locations(code,name,kind) values ('TRANSIT','Dalam Perjalanan (In Transit)','in_transit')
on conflict (code) do nothing;

create or replace function public.trg_branch_locations() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into stock_locations(branch_id, code, name, kind) values
    (new.id, new.code||'-UTM', new.name||' · Utama', 'main'),
    (new.id, new.code||'-KRT', new.name||' · Karantina Retur', 'quarantine'),
    (new.id, new.code||'-SCR', new.name||' · Scrap', 'scrap'),
    (new.id, new.code||'-OFC', new.name||' · Sisa Bahan', 'offcut')
  on conflict (code) do nothing;
  return new;
end $$;
drop trigger if exists branch_locations on public.branches;
create trigger branch_locations after insert on public.branches
  for each row execute function public.trg_branch_locations();

-- ---------- pengguna ----------
create table if not exists public.profiles (
  id uuid primary key references auth.users on delete cascade,
  email text, full_name text, phone text,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles(id, email, full_name)
  values (new.id, new.email, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)))
  on conflict (id) do nothing;
  return new;
end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();
insert into public.profiles(id,email,full_name)
  select id, email, split_part(email,'@',1) from auth.users on conflict (id) do nothing;

create table if not exists public.user_roles (
  user_id uuid references public.profiles on delete cascade,
  role text references public.roles,
  granted_by uuid, granted_at timestamptz not null default now(),
  primary key (user_id, role)
);
create table if not exists public.user_branches (
  user_id uuid references public.profiles on delete cascade,
  branch_id uuid references public.branches,
  primary key (user_id, branch_id)
);

create table if not exists public.role_permissions (
  role text references public.roles,
  module text not null,
  can_view boolean not null default false,
  can_create boolean not null default false,
  can_edit boolean not null default false,
  can_approve boolean not null default false,
  primary key (role, module)
);

create table if not exists public.app_settings (
  key text primary key, value jsonb not null, label text
);
insert into public.app_settings(key,value,label) values
 ('company_name','"Kertajaya Piala"','Nama perusahaan'),
 ('po_approval_threshold','5000000','PO di atas nilai ini butuh approval (Rp)'),
 ('adj_hq_threshold','500000','Penyesuaian/opname di atas nilai ini wajib approval Area Manager/Owner (Rp)'),
 ('dp_min_pct','50','DP minimum pesanan custom non-marketplace (%)'),
 ('return_aging_days','7','Retur belum diterima dianggap telat setelah (hari)'),
 ('transit_aging_days','3','Transfer in-transit dianggap menggantung setelah (hari)'),
 ('unpaid_order_hours','24','Pesanan manual tanpa bukti bayar dianggap telat setelah (jam)'),
 ('shrinkage_alert_pct','1','Ambang shrinkage cabang per 30 hari (% nilai stok)'),
 ('void_alert_count','3','Jumlah void per kasir per hari yang memicu alert'),
 ('discount_alert_pct','10','Rata-rata diskon kasir per hari yang memicu alert (%)'),
 ('return_rate_alert_pct','5','Rasio retur channel 30 hari yang memicu alert (%)'),
 ('bad_debt_days','60','Tagihan lewat jatuh tempo lebih dari (hari) dianggap macet → order baru diblokir')
on conflict (key) do nothing;

create table if not exists public.doc_sequences (
  prefix text, period text, last_no int not null default 0, primary key (prefix, period)
);

create or replace function public.next_no(p_prefix text) returns text
language plpgsql security definer set search_path = public as $$
declare v_period text := to_char(now() at time zone 'Asia/Jakarta','YYMM'); v_n int;
begin
  insert into doc_sequences(prefix, period, last_no) values (p_prefix, v_period, 1)
  on conflict (prefix, period) do update set last_no = doc_sequences.last_no + 1
  returning last_no into v_n;
  return p_prefix || '-' || v_period || '-' || lpad(v_n::text, 4, '0');
end $$;

create or replace function public.setting_num(p_key text) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce((select (value #>> '{}')::numeric from app_settings where key = p_key), 0)
$$;

-- ---------- audit log (append-only) ----------
create table if not exists public.audit_log (
  id bigserial primary key,
  at timestamptz not null default now(),
  user_id uuid default auth.uid(),
  table_name text not null,
  record_id text,
  action text not null,
  old_data jsonb, new_data jsonb, note text
);
create index if not exists audit_log_tbl on public.audit_log(table_name, record_id);

create or replace function public.trg_audit() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_old jsonb; v_new jsonb; v_id text;
begin
  if tg_op = 'DELETE' then
    v_old := to_jsonb(old);
  elsif tg_op = 'UPDATE' then
    select jsonb_object_agg(k, to_jsonb(old)->k), jsonb_object_agg(k, to_jsonb(new)->k)
      into v_old, v_new
      from jsonb_object_keys(to_jsonb(new)) as k
     where k not in ('updated_at') and (to_jsonb(new)->k) is distinct from (to_jsonb(old)->k);
    if v_new is null then return new; end if;
  else
    v_new := to_jsonb(new);
  end if;
  v_id := coalesce(to_jsonb(coalesce(new, old))->>'id', to_jsonb(coalesce(new, old))->>'user_id', to_jsonb(coalesce(new, old))->>'product_id',
                   to_jsonb(coalesce(new, old))->>'key');
  insert into audit_log(table_name, record_id, action, old_data, new_data)
  values (tg_table_name, v_id, tg_op, v_old, v_new);
  return coalesce(new, old);
end $$;

create or replace function public.trg_no_delete() returns trigger language plpgsql as $$
begin
  -- hanya fungsi sistem yang boleh mengganti baris draft (mis. isi PO/SO yang belum dikonfirmasi)
  if current_setting('erp.allow_draft_rewrite', true) = 'on' then return old; end if;
  raise exception 'Data % tidak boleh dihapus. Nonaktifkan atau buat dokumen pembalik.', tg_table_name;
end $$;

create or replace function public.trg_no_update() returns trigger language plpgsql as $$
begin
  raise exception 'Data % bersifat append-only dan tidak boleh diubah.', tg_table_name;
end $$;

drop trigger if exists audit_no_upd on public.audit_log;
create trigger audit_no_upd before update or delete on public.audit_log
  for each row execute function public.trg_no_update();

-- ---------- helper hak akses ----------
create or replace function public.is_active_user() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from profiles where id = auth.uid() and active)
$$;

create or replace function public.my_roles() returns text[]
language sql stable security definer set search_path = public as $$
  select coalesce(array_agg(ur.role), '{}'::text[])
    from user_roles ur join profiles p on p.id = ur.user_id
   where ur.user_id = auth.uid() and p.active
$$;

create or replace function public.has_role(r text) returns boolean
language sql stable security definer set search_path = public as $$
  select r = any(public.my_roles())
$$;

create or replace function public.is_global() returns boolean
language sql stable security definer set search_path = public as $$
  select exists(select 1 from user_roles ur join roles ro on ro.code = ur.role
                 join profiles p on p.id = ur.user_id
                where ur.user_id = auth.uid() and p.active and ro.is_global)
$$;

create or replace function public.can_branch(b uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.is_active_user() and (b is null or public.is_global()
     or exists(select 1 from user_branches where user_id = auth.uid() and branch_id = b))
$$;

create or replace function public.can_loc(l uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select public.can_branch((select branch_id from stock_locations where id = l))
$$;

create or replace function public.has_perm(m text, a text) returns boolean
language sql stable security definer set search_path = public as $$
  select public.has_role('owner') or exists(
    select 1 from user_roles ur join profiles p on p.id = ur.user_id
      join role_permissions rp on rp.role = ur.role
     where ur.user_id = auth.uid() and p.active and rp.module = m
       and case a when 'view' then rp.can_view or rp.can_create or rp.can_edit or rp.can_approve
                  when 'create' then rp.can_create
                  when 'edit' then rp.can_edit
                  when 'approve' then rp.can_approve else false end)
$$;

create or replace function public.require_perm(m text, a text) returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null then raise exception 'Sesi login tidak ditemukan. Silakan masuk lagi.'; end if;
  if not public.has_perm(m, a) then
    raise exception 'Akses ditolak: jabatan Anda tidak punya izin % pada modul %.', a, m;
  end if;
end $$;

create or replace function public.require_branch(b uuid) returns void
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.can_branch(b) then raise exception 'Akses ditolak: Anda tidak terdaftar di cabang ini.'; end if;
end $$;

create or replace function public.my_discount_limit() returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(max(r.discount_limit_pct), 0) from roles r where r.code = any(public.my_roles())
$$;

-- pemisahan tugas saat memberi jabatan
create or replace function public.trg_sod_check() returns trigger
language plpgsql security definer set search_path = public as $$
declare v_reason text;
begin
  select c.reason into v_reason
    from sod_conflicts c join user_roles ur on ur.user_id = new.user_id
   where (c.role_a = new.role and c.role_b = ur.role) or (c.role_b = new.role and c.role_a = ur.role)
   limit 1;
  if v_reason is not null then
    raise exception 'Rangkap jabatan ditolak (pemisahan tugas): %', v_reason;
  end if;
  new.granted_by := auth.uid();
  return new;
end $$;
drop trigger if exists sod_check on public.user_roles;
create trigger sod_check before insert on public.user_roles
  for each row execute function public.trg_sod_check();

drop trigger if exists audit_user_roles on public.user_roles;
create trigger audit_user_roles after insert or delete on public.user_roles
  for each row execute function public.trg_audit();
drop trigger if exists audit_user_branches on public.user_branches;
create trigger audit_user_branches after insert or delete on public.user_branches
  for each row execute function public.trg_audit();
drop trigger if exists audit_profiles on public.profiles;
create trigger audit_profiles after update on public.profiles
  for each row execute function public.trg_audit();
drop trigger if exists audit_role_perm on public.role_permissions;
create trigger audit_role_perm after insert or update on public.role_permissions
  for each row execute function public.trg_audit();
drop trigger if exists audit_settings on public.app_settings;
create trigger audit_settings after insert or update on public.app_settings
  for each row execute function public.trg_audit();
drop trigger if exists audit_roles on public.roles;
create trigger audit_roles after update on public.roles
  for each row execute function public.trg_audit();
-- =====================================================================
--  MASTER DATA
-- =====================================================================
create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  barcode text unique,
  name text not null,
  category text not null check (category in ('piala_rakitan','akrilik_custom','barang_jadi','komponen','bahan_baku','jasa')),
  product_group text, size text, color text,
  uom text not null default 'pcs',
  price_retail numeric(14,2) not null default 0,
  price_reseller numeric(14,2) not null default 0,
  price_instansi numeric(14,2) not null default 0,
  avg_cost numeric(14,4) not null default 0,       -- HPP moving average (diisi sistem)
  std_cost numeric(14,4) not null default 0,       -- HPP rollup BOM (diisi sistem)
  labor_cost numeric(14,2) not null default 0,     -- upah rakit / jasa grafir per unit
  waste_pct numeric(5,2) not null default 0,       -- estimasi waste bahan lembaran
  min_stock numeric(14,3) not null default 0,
  track_serial boolean not null default false,
  requires_design boolean not null default false,
  sheet_w_mm numeric, sheet_h_mm numeric,          -- khusus bahan lembaran akrilik
  is_stock boolean generated always as (category <> 'jasa') stored,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.trg_products_guard() returns trigger
language plpgsql as $$
begin
  -- HPP hanya boleh diubah oleh fungsi sistem, bukan dari aplikasi
  if current_user in ('authenticated','anon') then
    if tg_op = 'INSERT' then
      new.avg_cost := 0; new.std_cost := 0;
    elsif new.avg_cost is distinct from old.avg_cost or new.std_cost is distinct from old.std_cost then
      raise exception 'HPP dihitung otomatis oleh sistem dan tidak bisa diubah manual.';
    end if;
  end if;
  new.updated_at := now();
  return new;
end $$;
drop trigger if exists products_guard on public.products;
create trigger products_guard before insert or update on public.products
  for each row execute function public.trg_products_guard();

create table if not exists public.bom_lines (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products,
  component_id uuid not null references public.products,
  qty numeric(14,5) not null check (qty > 0),
  cut_w_mm numeric, cut_h_mm numeric,
  note text,
  unique (product_id, component_id),
  check (product_id <> component_id)
);

create table if not exists public.cost_history (
  id bigserial primary key,
  product_id uuid not null references public.products,
  old_cost numeric(14,4), new_cost numeric(14,4),
  kind text not null default 'avg',
  source text, at timestamptz not null default now()
);

create table if not exists public.serial_units (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products,
  serial text not null unique,
  location_id uuid references public.stock_locations,
  status text not null default 'in_stock' check (status in ('in_stock','sold','quarantine','scrap')),
  last_doc_no text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.sales_channels (
  id uuid primary key default gen_random_uuid(),
  code text not null unique,
  name text not null,
  kind text not null check (kind in ('marketplace','offline','chat','website','maps','b2b')),
  admin_fee_pct numeric(6,3) not null default 0,
  settlement_days int not null default 0,
  active boolean not null default true
);
insert into public.sales_channels(code,name,kind,admin_fee_pct,settlement_days) values
 ('WALKIN','Toko / Walk-in','offline',0,0),
 ('SHOPEE','Shopee','marketplace',8,3),
 ('TOKOPEDIA','Tokopedia','marketplace',6.5,3),
 ('TIKTOK','TikTok Shop','marketplace',6,7),
 ('LAZADA','Lazada','marketplace',6,7),
 ('BLIBLI','Blibli','marketplace',5,7),
 ('WA','WhatsApp','chat',0,0),
 ('IG','Instagram','chat',0,0),
 ('FB','Facebook','chat',0,0),
 ('TTCHAT','TikTok Chat','chat',0,0),
 ('WEB','Website','website',0,0),
 ('GMAPS','Google Maps / Business','maps',0,0),
 ('B2B','Instansi / Sekolah / EO','b2b',0,0)
on conflict (code) do nothing;

create table if not exists public.customers (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  name text not null,
  kind text not null default 'retail' check (kind in ('retail','reseller','instansi')),
  phone text, email text, address text,
  credit_limit numeric(14,2) not null default 0,     -- 0 = tanpa kredit (bayar di muka)
  terms_days int not null default 0,
  blocked boolean not null default false,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.suppliers (
  id uuid primary key default gen_random_uuid(),
  code text unique,
  name text not null,
  phone text, email text, address text,
  lead_time_days int not null default 7,
  terms_days int not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.bank_accounts (
  id uuid primary key default gen_random_uuid(),
  bank_name text not null,
  account_no text not null unique,
  account_name text not null,
  kind text not null default 'bank' check (kind in ('bank','ewallet','qris','marketplace')),
  branch_id uuid references public.branches,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.adjustment_reasons (
  code text primary key, name text not null,
  direction text not null check (direction in ('in','out','both')),
  account_code text not null
);

create table if not exists public.return_reasons (
  code text primary key, name text not null,
  default_party text not null check (default_party in ('branch','operator','warehouse','courier','customer','company'))
);
insert into public.return_reasons values
 ('salah_grafir','Salah grafir / cetak (internal)','operator'),
 ('salah_kirim','Salah kirim (gudang)','warehouse'),
 ('rusak_jalan','Rusak di perjalanan (kurir)','courier'),
 ('salah_pesan','Salah pesan (pelanggan)','customer'),
 ('berubah_pikiran','Berubah pikiran','customer'),
 ('tidak_sesuai','Barang tidak sesuai ekspektasi','company')
on conflict do nothing;

-- ---------- bagan akun (sederhana) ----------
create table if not exists public.accounts (
  code text primary key, name text not null,
  kind text not null check (kind in ('asset','liability','equity','revenue','contra_revenue','cogs','expense'))
);
insert into public.accounts values
 ('1101','Kas Cabang','asset'), ('1102','Bank & E-wallet','asset'),
 ('1201','Piutang Usaha','asset'), ('1202','Piutang Klaim Ekspedisi','asset'),
 ('1301','Persediaan','asset'), ('1302','Barang Dalam Proses','asset'),
 ('2101','Utang Dagang','liability'), ('2201','Uang Muka Pelanggan (DP)','liability'),
 ('3101','Modal','equity'), ('3201','Laba Ditahan','equity'),
 ('4101','Penjualan','revenue'), ('4102','Pendapatan Ongkir','revenue'),
 ('4103','Diskon Penjualan','contra_revenue'), ('4104','Retur Penjualan','contra_revenue'),
 ('5101','Harga Pokok Penjualan','cogs'), ('5102','Selisih Persediaan','cogs'),
 ('5103','Selisih Harga Beli','cogs'), ('5104','Beban Scrap & Write-off','cogs'),
 ('5105','Upah Produksi Diserap','cogs'),
 ('6101','Gaji & Upah','expense'), ('6102','Sewa','expense'), ('6103','Listrik, Air & Internet','expense'),
 ('6104','Iklan & Promosi','expense'), ('6105','Transportasi','expense'), ('6106','ATK & Kemasan','expense'),
 ('6107','Perawatan & Perbaikan','expense'), ('6108','Ongkir Ditanggung Toko','expense'),
 ('6199','Biaya Lain-lain','expense'),
 ('6201','Biaya Admin Channel','expense'), ('6202','Voucher Ditanggung Penjual','expense'),
 ('6203','Selisih Kas','expense'), ('6204','Selisih Settlement Marketplace','expense'),
 ('6205','Kerugian Klaim Ekspedisi','expense')
on conflict do nothing;

insert into public.adjustment_reasons values
 ('saldo_awal','Saldo awal stok','in','3101'),
 ('ditemukan','Ditemukan kembali','in','5102'),
 ('hilang','Hilang','out','5102'),
 ('rusak','Rusak','out','5104'),
 ('susut','Susut','out','5102'),
 ('salah_input','Koreksi salah input','both','5102'),
 ('sampel_hadiah','Sampel / hadiah','out','6104'),
 ('selisih_opname','Selisih stock opname','both','5102')
on conflict do nothing;

create table if not exists public.expense_categories (
  code text primary key, name text not null, account_code text not null references public.accounts
);
insert into public.expense_categories values
 ('gaji','Gaji & upah','6101'), ('sewa','Sewa','6102'), ('utilitas','Listrik, air, internet','6103'),
 ('iklan','Iklan & promosi','6104'), ('transport','Transportasi','6105'), ('atk','ATK & kemasan','6106'),
 ('perawatan','Perawatan & perbaikan','6107'), ('ongkir','Ongkir ditanggung toko','6108'),
 ('lainnya','Lain-lain (wajib keterangan)','6199')
on conflict do nothing;

-- tidak ada hapus untuk master penting (pakai nonaktif)
do $$ declare t text; begin
  foreach t in array array['products','sales_channels','customers','suppliers','bank_accounts','branches','stock_locations','serial_units','cost_history'] loop
    execute format('drop trigger if exists no_delete on public.%I', t);
    execute format('create trigger no_delete before delete on public.%I for each row execute function public.trg_no_delete()', t);
  end loop;
  foreach t in array array['products','sales_channels','customers','suppliers','bank_accounts','branches','bom_lines'] loop
    execute format('drop trigger if exists audit_row on public.%I', t);
    execute format('create trigger audit_row after insert or update or delete on public.%I for each row execute function public.trg_audit()', t);
  end loop;
end $$;
-- =====================================================================
--  TABEL TRANSAKSI
-- =====================================================================

-- ---------- persediaan ----------
create table if not exists public.stock_ledger (
  id bigserial primary key,
  at timestamptz not null default now(),
  product_id uuid not null references public.products,
  location_id uuid not null references public.stock_locations,
  qty numeric(14,3) not null check (qty <> 0),
  unit_cost numeric(14,4) not null default 0,
  value numeric(16,2) generated always as (round(qty * unit_cost, 2)) stored,
  doc_type text not null,
  doc_id uuid,
  doc_no text not null,
  note text,
  serial text,
  user_id uuid default auth.uid()
);
create index if not exists stock_ledger_prod on public.stock_ledger(product_id, location_id, at);
create index if not exists stock_ledger_doc on public.stock_ledger(doc_id);

create table if not exists public.stock_balances (
  product_id uuid references public.products,
  location_id uuid references public.stock_locations,
  qty numeric(14,3) not null default 0,
  reserved numeric(14,3) not null default 0 check (reserved >= 0),
  updated_at timestamptz not null default now(),
  primary key (product_id, location_id)
);

create table if not exists public.channel_allocations (
  product_id uuid references public.products,
  location_id uuid references public.stock_locations,
  channel_id uuid references public.sales_channels,
  qty numeric(14,3) not null default 0 check (qty >= 0),
  updated_at timestamptz not null default now(),
  updated_by uuid,
  primary key (product_id, location_id, channel_id)
);

create table if not exists public.stock_transfers (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  from_location_id uuid not null references public.stock_locations,
  to_location_id uuid not null references public.stock_locations,
  status text not null default 'in_transit' check (status in ('in_transit','received','received_diff','resolved')),
  note text,
  sent_by uuid references public.profiles, sent_at timestamptz not null default now(),
  received_by uuid references public.profiles, received_at timestamptz, receive_note text,
  diff_value numeric(16,2) not null default 0,
  resolved_by uuid references public.profiles, resolved_at timestamptz,
  responsible text, resolve_note text
);
create table if not exists public.transfer_lines (
  id uuid primary key default gen_random_uuid(),
  transfer_id uuid not null references public.stock_transfers,
  product_id uuid not null references public.products,
  qty_sent numeric(14,3) not null check (qty_sent > 0),
  qty_received numeric(14,3),
  unit_cost numeric(14,4) not null default 0
);

create table if not exists public.stock_opnames (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  location_id uuid not null references public.stock_locations,
  kind text not null check (kind in ('full','cycle')),
  status text not null default 'counting' check (status in ('counting','submitted','approved','rejected')),
  note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  counted_by uuid references public.profiles, submitted_at timestamptz,
  approved_by uuid references public.profiles, approved_at timestamptz, approve_note text,
  diff_value numeric(16,2) not null default 0
);
create table if not exists public.opname_lines (
  id uuid primary key default gen_random_uuid(),
  opname_id uuid not null references public.stock_opnames,
  product_id uuid not null references public.products,
  system_qty numeric(14,3),        -- disalin saat submit (hitung buta)
  counted_qty numeric(14,3),
  unit_cost numeric(14,4) not null default 0,
  unique (opname_id, product_id)
);

create table if not exists public.stock_adjustments (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  location_id uuid not null references public.stock_locations,
  reason_code text not null references public.adjustment_reasons,
  note text not null check (length(trim(note)) >= 10),
  photo_path text,
  source text not null default 'manual',
  source_id uuid,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  total_value numeric(16,2) not null default 0,
  requested_by uuid references public.profiles, requested_at timestamptz not null default now(),
  decided_by uuid references public.profiles, decided_at timestamptz, decide_note text
);
create table if not exists public.adjustment_lines (
  id uuid primary key default gen_random_uuid(),
  adjustment_id uuid not null references public.stock_adjustments,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty <> 0),
  unit_cost numeric(14,4) not null default 0
);

-- ---------- pembelian ----------
create table if not exists public.purchase_orders (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  supplier_id uuid not null references public.suppliers,
  location_id uuid not null references public.stock_locations,
  status text not null default 'draft' check (status in ('draft','pending_approval','approved','partial','received','closed','cancelled','rejected')),
  order_date date not null default public.today_jkt(),
  expected_date date,
  note text,
  total numeric(16,2) not null default 0,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  approved_by uuid references public.profiles, approved_at timestamptz, approve_note text,
  closed_reason text
);
create table if not exists public.po_lines (
  id uuid primary key default gen_random_uuid(),
  po_id uuid not null references public.purchase_orders,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty > 0),
  price numeric(14,2) not null check (price >= 0),
  qty_received numeric(14,3) not null default 0
);
create table if not exists public.goods_receipts (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  po_id uuid not null references public.purchase_orders,
  location_id uuid not null references public.stock_locations,
  received_by uuid references public.profiles, received_at timestamptz not null default now(),
  note text, has_diff boolean not null default false, total numeric(16,2) not null default 0
);
create table if not exists public.gr_lines (
  id uuid primary key default gen_random_uuid(),
  gr_id uuid not null references public.goods_receipts,
  po_line_id uuid not null references public.po_lines,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty > 0),
  qty_outstanding_before numeric(14,3) not null,
  unit_cost numeric(14,2) not null
);
create table if not exists public.supplier_invoices (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  po_id uuid not null references public.purchase_orders,
  supplier_id uuid not null references public.suppliers,
  invoice_no text not null,
  invoice_date date not null,
  due_date date,
  amount numeric(16,2) not null check (amount > 0),
  received_value numeric(16,2) not null default 0,
  po_value numeric(16,2) not null default 0,
  status text not null default 'matched' check (status in ('matched','blocked','approved','rejected','paid')),
  match_note text,
  proof_path text,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  decided_by uuid references public.profiles, decided_at timestamptz, decide_note text,
  paid_by uuid references public.profiles, paid_at timestamptz, pay_bank_id uuid references public.bank_accounts, pay_proof_path text,
  unique (supplier_id, invoice_no)
);
create table if not exists public.purchase_returns (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  supplier_id uuid not null references public.suppliers,
  po_id uuid references public.purchase_orders,
  location_id uuid not null references public.stock_locations,
  reason text not null,
  total numeric(16,2) not null default 0,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);
create table if not exists public.purchase_return_lines (
  id uuid primary key default gen_random_uuid(),
  return_id uuid not null references public.purchase_returns,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty > 0),
  unit_cost numeric(14,2) not null
);

-- ---------- penjualan ----------
create table if not exists public.sales_orders (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  kind text not null check (kind in ('pos','order','quotation')),
  channel_id uuid not null references public.sales_channels,
  branch_id uuid not null references public.branches,
  location_id uuid not null references public.stock_locations,
  customer_id uuid references public.customers,
  customer_name text not null,
  customer_phone text,
  price_tier text not null default 'retail' check (price_tier in ('retail','reseller','instansi')),
  status text not null default 'draft' check (status in ('quotation','draft','in_production','ready','shipped','completed','cancelled','void')),
  need_date date,
  spec_note text,
  marketplace_order_no text,
  subtotal numeric(16,2) not null default 0,         -- Σ qty × harga jual
  gross_list numeric(16,2) not null default 0,       -- Σ qty × harga daftar
  discount_amount numeric(16,2) not null default 0,  -- diskon nota
  shipping_charge numeric(16,2) not null default 0,  -- ongkir ditagih ke pelanggan
  total numeric(16,2) not null default 0,
  channel_fee numeric(16,2) not null default 0,
  voucher_seller numeric(16,2) not null default 0,
  dp_required numeric(16,2) not null default 0,
  paid_verified numeric(16,2) not null default 0,
  refund_total numeric(16,2) not null default 0,
  cogs numeric(16,2) not null default 0,
  discount_pct numeric(6,2) not null default 0,
  discount_status text not null default 'none' check (discount_status in ('none','pending','approved','rejected')),
  credit_status text not null default 'none' check (credit_status in ('none','pending','approved','rejected')),
  approval_by uuid references public.profiles, approval_note text,
  void_status text not null default 'none' check (void_status in ('none','pending','approved','rejected')),
  void_reason text, void_requested_by uuid references public.profiles, void_decided_by uuid references public.profiles, void_decided_at timestamptz,
  recognized_at timestamptz,
  due_date date,
  note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create unique index if not exists so_mp_unique on public.sales_orders(channel_id, marketplace_order_no) where marketplace_order_no is not null;
create index if not exists so_branch_date on public.sales_orders(branch_id, created_at);

create table if not exists public.so_lines (
  id uuid primary key default gen_random_uuid(),
  so_id uuid not null references public.sales_orders,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty > 0),
  list_price numeric(14,2) not null default 0,
  price numeric(14,2) not null check (price >= 0),
  engraving_text text,
  is_custom boolean not null default false,
  reserved_qty numeric(14,3) not null default 0,
  unit_cost numeric(14,4) not null default 0,
  serials text[]
);

create table if not exists public.cash_sessions (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  branch_id uuid not null references public.branches,
  opened_by uuid not null references public.profiles, opened_at timestamptz not null default now(),
  opening_cash numeric(16,2) not null default 0,
  status text not null default 'open' check (status in ('open','closed','approved','rejected')),
  closed_at timestamptz,
  expected_cash numeric(16,2), counted_cash numeric(16,2), diff numeric(16,2), diff_reason text,
  decided_by uuid references public.profiles, decided_at timestamptz, decide_note text,
  deposit_amount numeric(16,2), deposit_bank_id uuid references public.bank_accounts, deposit_proof_path text,
  deposit_status text not null default 'none' check (deposit_status in ('none','pending','verified','rejected')),
  deposit_by uuid references public.profiles, deposit_at timestamptz,
  deposit_verified_by uuid references public.profiles, deposit_verified_at timestamptz
);

create table if not exists public.channel_settlements (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  channel_id uuid not null references public.sales_channels,
  period_from date not null, period_to date not null,
  orders_count int not null default 0,
  gross numeric(16,2) not null default 0,
  fees numeric(16,2) not null default 0,
  vouchers numeric(16,2) not null default 0,
  refunds numeric(16,2) not null default 0,
  expected_net numeric(16,2) not null default 0,
  received_amount numeric(16,2) not null default 0,
  diff numeric(16,2) not null default 0,
  bank_account_id uuid references public.bank_accounts,
  proof_path text, note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);

create table if not exists public.bank_transactions (
  id uuid primary key default gen_random_uuid(),
  bank_account_id uuid not null references public.bank_accounts,
  tx_date date not null,
  description text not null default '',
  amount numeric(16,2) not null,
  ref text,
  matched_payment_id uuid,
  matched_note text,
  matched_by uuid references public.profiles, matched_at timestamptz,
  imported_by uuid references public.profiles, imported_at timestamptz not null default now(),
  unique (bank_account_id, tx_date, amount, description)
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  so_id uuid not null references public.sales_orders,
  branch_id uuid not null references public.branches,
  amount numeric(16,2) not null check (amount > 0),
  method text not null check (method in ('cash','transfer','qris','edc','marketplace')),
  bank_account_id uuid references public.bank_accounts,
  proof_path text,
  pay_date date not null default public.today_jkt(),
  status text not null default 'pending' check (status in ('pending','verified','rejected','void')),
  note text,
  cash_session_id uuid references public.cash_sessions,
  settlement_id uuid references public.channel_settlements,
  bank_tx_id uuid references public.bank_transactions,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  verified_by uuid references public.profiles, verified_at timestamptz, verify_note text,
  check (method = 'cash' or bank_account_id is not null)
);

-- ---------- produksi ----------
create table if not exists public.work_orders (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  so_id uuid references public.sales_orders,
  so_line_id uuid references public.so_lines,
  product_id uuid not null references public.products,
  qty numeric(14,3) not null check (qty > 0),
  location_id uuid not null references public.stock_locations,
  status text not null default 'waiting_design' check (status in ('waiting_design','waiting_approval','ready','in_progress','qc','done','cancelled')),
  spec text,
  assigned_to uuid references public.profiles,
  target_date date,
  started_at timestamptz, finished_at timestamptz,
  qc_by uuid references public.profiles, qc_at timestamptz, qc_note text,
  material_cost numeric(16,2) not null default 0,
  labor_cost numeric(16,2) not null default 0,
  scrap_cost numeric(16,2) not null default 0,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);
create table if not exists public.design_approvals (
  id uuid primary key default gen_random_uuid(),
  so_id uuid not null references public.sales_orders,
  version int not null default 1,
  file_path text not null,
  note text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  customer_proof_path text, customer_note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  decided_by uuid references public.profiles, decided_at timestamptz
);
create table if not exists public.wo_consumptions (
  id uuid primary key default gen_random_uuid(),
  wo_id uuid not null references public.work_orders,
  product_id uuid not null references public.products,
  qty numeric(14,5) not null check (qty > 0),
  unit_cost numeric(14,4) not null default 0,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);
create table if not exists public.wo_scraps (
  id uuid primary key default gen_random_uuid(),
  wo_id uuid not null references public.work_orders,
  product_id uuid not null references public.products,
  qty numeric(14,5) not null check (qty > 0),
  cause text not null check (cause in ('salah_grafir','plat_rusak','akrilik_pecah','potongan_meleset','salah_rakit','bahan_cacat','lainnya')),
  note text,
  operator_id uuid references public.profiles,
  photo_path text not null,
  unit_cost numeric(14,4) not null default 0,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);
create table if not exists public.offcuts (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  material_id uuid not null references public.products,
  width_mm numeric not null check (width_mm > 0),
  height_mm numeric not null check (height_mm > 0),
  location_id uuid not null references public.stock_locations,
  status text not null default 'available' check (status in ('available','used','scrapped')),
  source_wo_id uuid references public.work_orders,
  used_wo_id uuid references public.work_orders,
  note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now()
);

-- ---------- logistik ----------
create table if not exists public.delivery_orders (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  so_id uuid not null references public.sales_orders,
  location_id uuid not null references public.stock_locations,
  status text not null default 'packing' check (status in ('packing','packed','shipped','delivered')),
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  packed_by uuid references public.profiles, packed_at timestamptz, packing_photo_path text, scan_log jsonb,
  courier text, tracking_no text, shipping_cost numeric(16,2) not null default 0,
  shipped_by uuid references public.profiles, shipped_at timestamptz,
  delivered_at timestamptz, delivered_by uuid references public.profiles, proof_path text,
  note text
);
create table if not exists public.courier_claims (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  do_id uuid not null references public.delivery_orders,
  courier text,
  reason text not null,
  claim_amount numeric(16,2) not null check (claim_amount > 0),
  status text not null default 'submitted' check (status in ('submitted','approved','rejected','paid')),
  received_amount numeric(16,2) not null default 0,
  note text,
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  updated_by uuid references public.profiles, updated_at timestamptz
);

-- ---------- retur ----------
create table if not exists public.sales_returns (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  so_id uuid not null references public.sales_orders,
  channel_id uuid not null references public.sales_channels,
  branch_id uuid not null references public.branches,
  location_id uuid not null references public.stock_locations,   -- lokasi karantina
  return_tracking_no text, courier text,
  reason_code text not null references public.return_reasons,
  reason_note text,
  refund_amount numeric(16,2) not null default 0,
  status text not null default 'expected' check (status in ('expected','received','dispositioned','cancelled')),
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  received_by uuid references public.profiles, received_at timestamptz, unboxing_photo_path text, receive_note text,
  disposition text check (disposition in ('rework','markdown','writeoff')),
  charge_to text check (charge_to in ('branch','operator','warehouse','courier','customer','company')),
  charge_party text,
  cost_value numeric(16,2) not null default 0,
  disposed_by uuid references public.profiles, disposed_at timestamptz, dispose_note text
);
create table if not exists public.return_lines (
  id uuid primary key default gen_random_uuid(),
  return_id uuid not null references public.sales_returns,
  product_id uuid not null references public.products,
  qty_expected numeric(14,3) not null check (qty_expected > 0),
  qty_received numeric(14,3),
  unit_cost numeric(14,4) not null default 0,
  condition text
);

-- ---------- keuangan ----------
create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  branch_id uuid not null references public.branches,
  exp_date date not null default public.today_jkt(),
  category text not null references public.expense_categories,
  amount numeric(16,2) not null check (amount > 0),
  description text not null,
  pay_method text not null check (pay_method in ('cash','bank')),
  bank_account_id uuid references public.bank_accounts,
  cash_session_id uuid references public.cash_sessions,
  proof_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_by uuid references public.profiles, created_at timestamptz not null default now(),
  decided_by uuid references public.profiles, decided_at timestamptz, decide_note text
);

create table if not exists public.journal_entries (
  id uuid primary key default gen_random_uuid(),
  no text not null unique,
  jdate date not null,
  memo text,
  branch_id uuid references public.branches,
  source_type text, source_id uuid,
  created_by uuid default auth.uid(), created_at timestamptz not null default now()
);
create table if not exists public.journal_lines (
  id bigserial primary key,
  entry_id uuid not null references public.journal_entries,
  account_code text not null references public.accounts,
  debit numeric(16,2) not null default 0,
  credit numeric(16,2) not null default 0,
  check (debit >= 0 and credit >= 0 and not (debit > 0 and credit > 0))
);
create index if not exists jl_entry on public.journal_lines(entry_id);
create index if not exists je_source on public.journal_entries(source_id);

-- ---------- larangan hapus & ubah ----------
do $$ declare t text; begin
  foreach t in array array['stock_transfers','transfer_lines','stock_opnames','opname_lines','stock_adjustments','adjustment_lines',
     'purchase_orders','po_lines','goods_receipts','gr_lines','supplier_invoices','purchase_returns','purchase_return_lines',
     'sales_orders','so_lines','cash_sessions','channel_settlements','bank_transactions','payments',
     'work_orders','design_approvals','wo_consumptions','wo_scraps','offcuts','delivery_orders','courier_claims',
     'sales_returns','return_lines','expenses','journal_entries','journal_lines','stock_balances'] loop
    execute format('drop trigger if exists no_delete on public.%I', t);
    execute format('create trigger no_delete before delete on public.%I for each row execute function public.trg_no_delete()', t);
  end loop;
  foreach t in array array['stock_ledger','journal_lines','wo_consumptions','wo_scraps','gr_lines','purchase_return_lines'] loop
    execute format('drop trigger if exists no_update on public.%I', t);
    execute format('create trigger no_update before update or delete on public.%I for each row execute function public.trg_no_update()', t);
  end loop;
  -- jejak perubahan data sensitif
  foreach t in array array['sales_orders','payments','cash_sessions','stock_adjustments','stock_opnames','purchase_orders',
     'supplier_invoices','expenses','sales_returns','stock_transfers','courier_claims','channel_allocations'] loop
    execute format('drop trigger if exists audit_row on public.%I', t);
    execute format('create trigger audit_row after insert or update on public.%I for each row execute function public.trg_audit()', t);
  end loop;
end $$;
-- =====================================================================
--  MESIN INTI: kartu stok, HPP moving average, jurnal
--  Fungsi berawalan "_" hanya bisa dipanggil dari fungsi lain (bukan dari aplikasi).
-- =====================================================================

create or replace function public._uid() returns uuid
language plpgsql stable security definer set search_path = public as $$
begin
  if auth.uid() is null or not public.is_active_user() then
    raise exception 'Sesi login tidak valid atau akun nonaktif.';
  end if;
  return auth.uid();
end $$;

-- posting kartu stok: satu-satunya jalan stok berubah
create or replace function public._post_stock(
  p_product uuid, p_location uuid, p_qty numeric, p_cost numeric,
  p_doc_type text, p_doc_id uuid, p_doc_no text, p_note text default null,
  p_release numeric default 0, p_force boolean default false, p_serial text default null)
returns numeric
language plpgsql security definer set search_path = public as $$
declare v_prod products; v_bal stock_balances; v_cost numeric; v_loc stock_locations; v_res numeric;
begin
  if p_qty = 0 then return 0; end if;
  select * into v_prod from products where id = p_product;
  if not found then raise exception 'Produk tidak ditemukan.'; end if;
  if not v_prod.is_stock then return 0; end if;
  select * into v_loc from stock_locations where id = p_location;
  if not found then raise exception 'Lokasi stok tidak ditemukan.'; end if;

  insert into stock_balances(product_id, location_id) values (p_product, p_location) on conflict do nothing;
  select * into v_bal from stock_balances where product_id = p_product and location_id = p_location for update;
  v_cost := coalesce(p_cost, v_prod.avg_cost);
  v_res := greatest(v_bal.reserved - coalesce(p_release,0), 0);

  if p_qty < 0 then
    if v_bal.qty + p_qty < 0 then
      raise exception 'Stok tidak cukup: % (%) di % — stok %, dibutuhkan %.',
        v_prod.name, v_prod.sku, v_loc.name, v_bal.qty, -p_qty;
    end if;
    if not p_force and v_bal.qty + p_qty < v_res then
      raise exception 'Stok % di % sudah dipesan order lain (stok %, dipesan %). Transaksi ditolak.',
        v_prod.sku, v_loc.name, v_bal.qty, v_bal.reserved;
    end if;
  end if;

  insert into stock_ledger(product_id, location_id, qty, unit_cost, doc_type, doc_id, doc_no, note, serial)
  values (p_product, p_location, p_qty, v_cost, p_doc_type, p_doc_id, p_doc_no, p_note, p_serial);

  update stock_balances set qty = qty + p_qty, reserved = v_res, updated_at = now()
   where product_id = p_product and location_id = p_location;
  return v_cost;
end $$;

create or replace function public._reserve(p_product uuid, p_location uuid, p_qty numeric, p_force boolean default false)
returns void language plpgsql security definer set search_path = public as $$
declare v_bal stock_balances; v_sku text;
begin
  if p_qty <= 0 then return; end if;
  insert into stock_balances(product_id, location_id) values (p_product, p_location) on conflict do nothing;
  select * into v_bal from stock_balances where product_id = p_product and location_id = p_location for update;
  if not p_force and v_bal.qty - v_bal.reserved < p_qty then
    select sku into v_sku from products where id = p_product;
    raise exception 'Stok tersedia % tidak cukup untuk dipesan (tersedia %, butuh %).', v_sku, v_bal.qty - v_bal.reserved, p_qty;
  end if;
  update stock_balances set reserved = reserved + p_qty, updated_at = now()
   where product_id = p_product and location_id = p_location;
end $$;

create or replace function public._unreserve(p_product uuid, p_location uuid, p_qty numeric)
returns void language plpgsql security definer set search_path = public as $$
begin
  update stock_balances set reserved = greatest(reserved - p_qty, 0), updated_at = now()
   where product_id = p_product and location_id = p_location;
end $$;

-- stok bebas untuk dijual (dikurangi reservasi & alokasi channel lain)
create or replace function public._free_qty(p_product uuid, p_location uuid, p_channel uuid default null)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce((select qty - reserved from stock_balances where product_id = p_product and location_id = p_location), 0)
       - coalesce((select sum(qty) from channel_allocations where product_id = p_product and location_id = p_location
                     and (p_channel is null or channel_id <> p_channel)), 0)
$$;

-- HPP moving average: panggil SEBELUM barang masuk diposting
create or replace function public._apply_avg(p_product uuid, p_qty numeric, p_cost numeric, p_source text)
returns void language plpgsql security definer set search_path = public as $$
declare v_total numeric; v_old numeric; v_new numeric;
begin
  if p_qty <= 0 or p_cost is null then return; end if;
  select avg_cost into v_old from products where id = p_product for update;
  select coalesce(sum(b.qty), 0) into v_total
    from stock_balances b join stock_locations l on l.id = b.location_id
   where b.product_id = p_product and l.kind <> 'scrap';
  v_total := greatest(v_total, 0);
  v_new := round((v_total * v_old + p_qty * p_cost) / (v_total + p_qty), 4);
  if v_new is distinct from v_old then
    update products set avg_cost = v_new where id = p_product;
    insert into cost_history(product_id, old_cost, new_cost, kind, source) values (p_product, v_old, v_new, 'avg', p_source);
  end if;
end $$;

-- HPP rollup dari BOM (komponen + waste bahan lembaran + upah/jasa)
create or replace function public.bom_cost(p_product uuid) returns numeric
language sql stable security definer set search_path = public as $$
  select coalesce(sum(b.qty * c.avg_cost * case when c.category = 'bahan_baku' then 1 + p.waste_pct/100 else 1 end), 0) + max(p.labor_cost)
    from products p left join bom_lines b on b.product_id = p.id left join products c on c.id = b.component_id
   where p.id = p_product
$$;

create or replace function public.recalc_bom_costs() returns int
language plpgsql security definer set search_path = public as $$
declare r record; v_new numeric; n int := 0;
begin
  for r in select distinct p.id, p.std_cost from products p join bom_lines b on b.product_id = p.id loop
    v_new := round(bom_cost(r.id), 4);
    if v_new is distinct from r.std_cost then
      update products set std_cost = v_new where id = r.id;
      insert into cost_history(product_id, old_cost, new_cost, kind, source) values (r.id, r.std_cost, v_new, 'bom', 'rekalkulasi BOM');
      n := n + 1;
    end if;
  end loop;
  return n;
end $$;

-- jurnal: p_lines = [{"a":"1102","d":100}, {"a":"4101","c":100}]  (nilai negatif otomatis dibalik sisi)
create or replace function public._post_journal(p_date date, p_memo text, p_branch uuid,
  p_src_type text, p_src_id uuid, p_lines jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_d numeric; v_c numeric;
begin
  with x as (
    select e->>'a' a, round(coalesce((e->>'d')::numeric,0),2) d, round(coalesce((e->>'c')::numeric,0),2) c
      from jsonb_array_elements(p_lines) e)
  select coalesce(sum(greatest(d,0) + greatest(-c,0)),0), coalesce(sum(greatest(c,0) + greatest(-d,0)),0)
    into v_d, v_c from x;
  if v_d <> v_c then raise exception 'Jurnal % tidak seimbang (debit % ≠ kredit %).', p_memo, v_d, v_c; end if;
  if v_d = 0 then return null; end if;
  insert into journal_entries(no, jdate, memo, branch_id, source_type, source_id)
  values (next_no('JU'), coalesce(p_date, today_jkt()), p_memo, p_branch, p_src_type, p_src_id)
  returning id into v_id;
  insert into journal_lines(entry_id, account_code, debit, credit)
  select v_id, a, dd, cc from (
    select e->>'a' a,
      greatest(round(coalesce((e->>'d')::numeric,0),2),0) + greatest(-round(coalesce((e->>'c')::numeric,0),2),0) dd,
      greatest(round(coalesce((e->>'c')::numeric,0),2),0) + greatest(-round(coalesce((e->>'d')::numeric,0),2),0) cc
    from jsonb_array_elements(p_lines) e) z
  where dd <> 0 or cc <> 0;
  -- baris yang punya debit & kredit sekaligus dinetralkan
  update journal_lines set debit = greatest(debit - credit, 0), credit = greatest(credit - debit, 0)
   where entry_id = v_id and debit > 0 and credit > 0;
  return v_id;
end $$;

-- membalik semua jurnal milik sebuah sumber (untuk void)
create or replace function public._reverse_journals(p_src_id uuid, p_memo text) returns void
language plpgsql security definer set search_path = public as $$
declare r record; v_id uuid;
begin
  for r in select * from journal_entries where source_id = p_src_id and source_type <> 'REVERSAL' loop
    insert into journal_entries(no, jdate, memo, branch_id, source_type, source_id)
    values (next_no('JU'), today_jkt(), p_memo || ' (pembalik ' || r.no || ')', r.branch_id, 'REVERSAL', p_src_id)
    returning id into v_id;
    insert into journal_lines(entry_id, account_code, debit, credit)
    select v_id, account_code, credit, debit from journal_lines where entry_id = r.id;
  end loop;
end $$;

create or replace function public._branch_of_loc(p_loc uuid) returns uuid
language sql stable security definer set search_path = public as $$ select branch_id from stock_locations where id = p_loc $$;

create or replace function public._loc_of_kind(p_branch uuid, p_kind text) returns uuid
language plpgsql stable security definer set search_path = public as $$
declare v uuid;
begin
  select id into v from stock_locations where branch_id = p_branch and kind = p_kind and active order by code limit 1;
  if v is null then raise exception 'Lokasi % untuk cabang ini belum ada.', p_kind; end if;
  return v;
end $$;

create or replace function public._outstanding(s sales_orders) returns numeric
language sql immutable as $$
  select s.total - s.channel_fee - s.voucher_seller - s.refund_total - s.paid_verified
$$;

-- pengakuan pendapatan & HPP saat serah terima barang
create or replace function public._recognize_so(p_so uuid) returns void
language plpgsql security definer set search_path = public as $$
declare s sales_orders; v_cogs numeric; v_disc numeric; v_terms int := 0;
begin
  select * into s from sales_orders where id = p_so for update;
  if s.recognized_at is not null then return; end if;
  select coalesce(sum(round(qty * unit_cost, 2)), 0) into v_cogs from so_lines where so_id = p_so;
  v_disc := s.gross_list - (s.subtotal - s.discount_amount);
  if s.customer_id is not null then select terms_days into v_terms from customers where id = s.customer_id; end if;
  update sales_orders set recognized_at = now(), cogs = v_cogs, due_date = today_jkt() + coalesce(v_terms,0), updated_at = now()
   where id = p_so;
  perform _post_journal(today_jkt(), 'Penjualan ' || s.no, s.branch_id, 'SO', s.id, jsonb_build_array(
    jsonb_build_object('a','1201','d', s.total),
    jsonb_build_object('a','4103','d', v_disc),
    jsonb_build_object('a','4101','c', s.gross_list),
    jsonb_build_object('a','4102','c', s.shipping_charge),
    jsonb_build_object('a','5101','d', v_cogs),
    jsonb_build_object('a','1301','c', v_cogs),
    jsonb_build_object('a','6201','d', s.channel_fee),
    jsonb_build_object('a','6202','d', s.voucher_seller),
    jsonb_build_object('a','1201','c', s.channel_fee + s.voucher_seller),
    jsonb_build_object('a','2201','d', s.paid_verified),
    jsonb_build_object('a','1201','c', s.paid_verified)));
end $$;
-- =====================================================================
--  RPC: PEMBELIAN
-- =====================================================================
create or replace function public.po_save(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p->>'id','')::uuid; v_po purchase_orders; l jsonb; v_total numeric := 0;
begin
  perform require_perm('purchasing','create');
  perform require_branch(_branch_of_loc((p->>'location_id')::uuid));
  if jsonb_array_length(coalesce(p->'lines','[]')) = 0 then raise exception 'PO minimal berisi 1 barang.'; end if;
  if v_id is null then
    insert into purchase_orders(no, supplier_id, location_id, expected_date, note, created_by)
    values (next_no('PO'), (p->>'supplier_id')::uuid, (p->>'location_id')::uuid, nullif(p->>'expected_date','')::date, p->>'note', _uid())
    returning id into v_id;
  else
    select * into v_po from purchase_orders where id = v_id for update;
    if v_po.status <> 'draft' then raise exception 'PO % sudah diajukan, tidak bisa diubah.', v_po.no; end if;
    update purchase_orders set supplier_id = (p->>'supplier_id')::uuid, location_id = (p->>'location_id')::uuid,
      expected_date = nullif(p->>'expected_date','')::date, note = p->>'note' where id = v_id;
    -- baris draft diganti (draft belum berdampak ke stok/uang)
    perform set_config('erp.allow_draft_rewrite','on',true);
    delete from po_lines where po_id = v_id;
    perform set_config('erp.allow_draft_rewrite','off',true);
  end if;
  for l in select * from jsonb_array_elements(p->'lines') loop
    insert into po_lines(po_id, product_id, qty, price) values (v_id, (l->>'product_id')::uuid, (l->>'qty')::numeric, (l->>'price')::numeric);
    v_total := v_total + (l->>'qty')::numeric * (l->>'price')::numeric;
  end loop;
  update purchase_orders set total = v_total where id = v_id;
  return v_id;
end $$;

create or replace function public.po_submit(p_id uuid) returns text
language plpgsql security definer set search_path = public as $$
declare v_po purchase_orders; v_status text;
begin
  perform require_perm('purchasing','create');
  select * into v_po from purchase_orders where id = p_id for update;
  if v_po.status <> 'draft' then raise exception 'Hanya PO draft yang bisa diajukan.'; end if;
  v_status := case when v_po.total > setting_num('po_approval_threshold') then 'pending_approval' else 'approved' end;
  update purchase_orders set status = v_status,
    approved_at = case when v_status = 'approved' then now() end,
    approve_note = case when v_status = 'approved' then 'Otomatis: di bawah batas approval' end
   where id = p_id;
  return v_status;
end $$;

create or replace function public.po_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare v_po purchase_orders;
begin
  perform require_perm('purchasing','approve');
  select * into v_po from purchase_orders where id = p_id for update;
  if v_po.status <> 'pending_approval' then raise exception 'PO tidak sedang menunggu approval.'; end if;
  if v_po.created_by = _uid() then raise exception 'Pembuat PO tidak boleh menyetujui PO sendiri.'; end if;
  update purchase_orders set status = case when p_approve then 'approved' else 'rejected' end,
    approved_by = _uid(), approved_at = now(), approve_note = p_note where id = p_id;
end $$;

create or replace function public.po_close(p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
declare v_po purchase_orders;
begin
  perform require_perm('purchasing','create');
  if length(trim(coalesce(p_reason,''))) < 5 then raise exception 'Alasan penutupan wajib diisi.'; end if;
  select * into v_po from purchase_orders where id = p_id for update;
  if v_po.status in ('draft','pending_approval','approved') and not exists(select 1 from goods_receipts where po_id = p_id) then
    update purchase_orders set status = 'cancelled', closed_reason = p_reason where id = p_id;
  elsif v_po.status = 'partial' then
    update purchase_orders set status = 'closed', closed_reason = p_reason where id = p_id;
  else
    raise exception 'PO % tidak bisa ditutup pada status %.', v_po.no, v_po.status;
  end if;
end $$;

-- penerimaan barang wajib mengacu PO; penerima ≠ pembuat PO
create or replace function public.grn_post(p_po uuid, p_lines jsonb, p_note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_po purchase_orders; v_gr uuid; v_no text; l jsonb; pl po_lines; v_qty numeric; v_total numeric := 0;
        v_diff boolean := false; v_prod products; i int; v_seq int;
begin
  perform require_perm('grn','create');
  select * into v_po from purchase_orders where id = p_po for update;
  if v_po.status not in ('approved','partial') then raise exception 'PO % belum disetujui atau sudah selesai.', v_po.no; end if;
  perform require_branch(_branch_of_loc(v_po.location_id));
  if v_po.created_by = _uid() then raise exception 'Pemisahan tugas: pembuat PO tidak boleh menerima barangnya sendiri.'; end if;
  v_no := next_no('GRN');
  insert into goods_receipts(no, po_id, location_id, received_by, note) values (v_no, p_po, v_po.location_id, _uid(), p_note)
  returning id into v_gr;
  for l in select * from jsonb_array_elements(p_lines) loop
    v_qty := coalesce((l->>'qty')::numeric, 0);
    continue when v_qty <= 0;
    select * into pl from po_lines where id = (l->>'po_line_id')::uuid and po_id = p_po for update;
    if not found then raise exception 'Baris PO tidak valid.'; end if;
    if v_qty > pl.qty - pl.qty_received then
      raise exception 'Jumlah diterima melebihi sisa PO (sisa %).', pl.qty - pl.qty_received;
    end if;
    select * into v_prod from products where id = pl.product_id;
    if v_prod.track_serial and v_qty <> trunc(v_qty) then raise exception 'Barang ber-serial harus diterima dalam jumlah bulat.'; end if;
    insert into gr_lines(gr_id, po_line_id, product_id, qty, qty_outstanding_before, unit_cost)
    values (v_gr, pl.id, pl.product_id, v_qty, pl.qty - pl.qty_received, pl.price);
    perform _apply_avg(pl.product_id, v_qty, pl.price, v_no);
    if v_prod.track_serial then
      select count(*) into v_seq from serial_units where product_id = pl.product_id;
      for i in 1..v_qty::int loop
        perform _post_stock(pl.product_id, v_po.location_id, 1, pl.price, 'GRN', v_gr, v_no, 'Terima dari PO ' || v_po.no, 0, false,
                            v_prod.sku || '-' || lpad((v_seq + i)::text, 5, '0'));
        insert into serial_units(product_id, serial, location_id, last_doc_no)
        values (pl.product_id, v_prod.sku || '-' || lpad((v_seq + i)::text, 5, '0'), v_po.location_id, v_no);
      end loop;
    else
      perform _post_stock(pl.product_id, v_po.location_id, v_qty, pl.price, 'GRN', v_gr, v_no, 'Terima dari PO ' || v_po.no);
    end if;
    update po_lines set qty_received = qty_received + v_qty where id = pl.id;
    if v_qty < pl.qty - pl.qty_received then v_diff := true; end if;
    v_total := v_total + round(v_qty * pl.price, 2);
  end loop;
  if v_total = 0 then raise exception 'Isi minimal satu jumlah barang diterima.'; end if;
  update goods_receipts set total = v_total, has_diff = v_diff where id = v_gr;
  update purchase_orders set status = case when exists(select 1 from po_lines where po_id = p_po and qty_received < qty)
                                           then 'partial' else 'received' end where id = p_po;
  perform _post_journal(today_jkt(), 'Penerimaan ' || v_no || ' / ' || v_po.no, _branch_of_loc(v_po.location_id), 'GRN', v_gr,
    jsonb_build_array(jsonb_build_object('a','1301','d',v_total), jsonb_build_object('a','2101','c',v_total)));
  perform recalc_bom_costs();
  return v_gr;
end $$;

-- faktur supplier + 3-way match (PO vs diterima vs faktur)
create or replace function public.sup_invoice_create(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_po purchase_orders; v_recv numeric; v_prev numeric; v_amt numeric := (p->>'amount')::numeric;
        v_status text; v_note text; v_id uuid; v_expected numeric;
begin
  perform require_perm('sup_invoice','create');
  select * into v_po from purchase_orders where id = (p->>'po_id')::uuid;
  if not found then raise exception 'PO tidak ditemukan.'; end if;
  select coalesce(sum(round(qty_received * price,2)),0) into v_recv from po_lines where po_id = v_po.id;
  select coalesce(sum(amount),0) into v_prev from supplier_invoices where po_id = v_po.id and status <> 'rejected';
  v_expected := v_recv - v_prev;
  if abs(v_amt - v_expected) <= 1 then
    v_status := 'matched'; v_note := 'Cocok: faktur = nilai barang diterima';
  else
    v_status := 'blocked';
    v_note := format('Tidak cocok: PO Rp %s, diterima Rp %s, sudah difakturkan Rp %s, faktur ini Rp %s (selisih Rp %s)',
                     v_po.total, v_recv, v_prev, v_amt, v_amt - v_expected);
  end if;
  insert into supplier_invoices(no, po_id, supplier_id, invoice_no, invoice_date, due_date, amount, received_value, po_value,
                                status, match_note, proof_path, created_by)
  values (next_no('INV-S'), v_po.id, v_po.supplier_id, p->>'invoice_no', (p->>'invoice_date')::date, nullif(p->>'due_date','')::date,
          v_amt, v_expected, v_po.total, v_status, v_note, p->>'proof_path', _uid())
  returning id into v_id;
  return jsonb_build_object('id', v_id, 'status', v_status, 'note', v_note);
end $$;

create or replace function public.sup_invoice_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare v supplier_invoices; v_diff numeric;
begin
  perform require_perm('sup_invoice','approve');
  select * into v from supplier_invoices where id = p_id for update;
  if v.status <> 'blocked' then raise exception 'Faktur tidak sedang diblokir.'; end if;
  if v.created_by = _uid() then raise exception 'Penginput faktur tidak boleh menyetujui faktur sendiri.'; end if;
  if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Alasan keputusan wajib diisi.'; end if;
  update supplier_invoices set status = case when p_approve then 'approved' else 'rejected' end,
    decided_by = _uid(), decided_at = now(), decide_note = p_note where id = p_id;
  if p_approve then
    v_diff := v.amount - v.received_value;
    perform _post_journal(today_jkt(), 'Selisih faktur ' || v.invoice_no, null, 'SINV', v.id, jsonb_build_array(
      jsonb_build_object('a','5103','d',v_diff), jsonb_build_object('a','2101','c',v_diff)));
  end if;
end $$;

create or replace function public.sup_invoice_pay(p_id uuid, p_bank uuid, p_proof text) returns void
language plpgsql security definer set search_path = public as $$
declare v supplier_invoices;
begin
  perform require_perm('payables','approve');
  select * into v from supplier_invoices where id = p_id for update;
  if v.status not in ('matched','approved') then raise exception 'Faktur belum lolos 3-way match / belum disetujui.'; end if;
  if v.created_by = _uid() then raise exception 'Penginput faktur tidak boleh membayar faktur sendiri.'; end if;
  if p_proof is null then raise exception 'Bukti transfer wajib diunggah.'; end if;
  if not exists(select 1 from bank_accounts where id = p_bank and active) then raise exception 'Rekening perusahaan tidak valid.'; end if;
  update supplier_invoices set status = 'paid', paid_by = _uid(), paid_at = now(), pay_bank_id = p_bank, pay_proof_path = p_proof where id = p_id;
  perform _post_journal(today_jkt(), 'Bayar faktur ' || v.invoice_no, null, 'SPAY', v.id, jsonb_build_array(
    jsonb_build_object('a','2101','d',v.amount), jsonb_build_object('a','1102','c',v.amount)));
end $$;

create or replace function public.purchase_return_post(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_no text; l jsonb; v_loc uuid := (p->>'location_id')::uuid; v_cost numeric; v_val_sup numeric := 0; v_val_inv numeric := 0;
begin
  perform require_perm('purchasing','create');
  perform require_branch(_branch_of_loc(v_loc));
  if length(trim(coalesce(p->>'reason',''))) < 10 then raise exception 'Alasan retur pembelian wajib dijelaskan (min. 10 karakter).'; end if;
  v_no := next_no('RB');
  insert into purchase_returns(no, supplier_id, po_id, location_id, reason, created_by)
  values (v_no, (p->>'supplier_id')::uuid, nullif(p->>'po_id','')::uuid, v_loc, p->>'reason', _uid()) returning id into v_id;
  for l in select * from jsonb_array_elements(p->'lines') loop
    v_cost := _post_stock((l->>'product_id')::uuid, v_loc, -(l->>'qty')::numeric, null, 'RB', v_id, v_no, 'Retur ke supplier');
    insert into purchase_return_lines(return_id, product_id, qty, unit_cost)
    values (v_id, (l->>'product_id')::uuid, (l->>'qty')::numeric, coalesce(nullif(l->>'unit_cost','')::numeric, v_cost));
    v_val_sup := v_val_sup + round((l->>'qty')::numeric * coalesce(nullif(l->>'unit_cost','')::numeric, v_cost), 2);
    v_val_inv := v_val_inv + round((l->>'qty')::numeric * v_cost, 2);
  end loop;
  update purchase_returns set total = v_val_sup where id = v_id;
  perform _post_journal(today_jkt(), 'Retur pembelian ' || v_no, _branch_of_loc(v_loc), 'RB', v_id, jsonb_build_array(
    jsonb_build_object('a','2101','d',v_val_sup), jsonb_build_object('a','1301','c',v_val_inv),
    jsonb_build_object('a','5103','c',v_val_sup - v_val_inv)));
  return v_id;
end $$;

-- =====================================================================
--  RPC: PERSEDIAAN
-- =====================================================================
create or replace function public.transfer_send(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_no text; l jsonb; v_from uuid := (p->>'from_location_id')::uuid; v_to uuid := (p->>'to_location_id')::uuid;
        v_transit uuid; v_cost numeric;
begin
  perform require_perm('transfer','create');
  perform require_branch(_branch_of_loc(v_from));
  if v_from = v_to then raise exception 'Lokasi asal dan tujuan tidak boleh sama.'; end if;
  if jsonb_array_length(coalesce(p->'lines','[]')) = 0 then raise exception 'Transfer minimal berisi 1 barang.'; end if;
  select id into v_transit from stock_locations where kind = 'in_transit' limit 1;
  v_no := next_no('TRF');
  insert into stock_transfers(no, from_location_id, to_location_id, note, sent_by) values (v_no, v_from, v_to, p->>'note', _uid())
  returning id into v_id;
  for l in select * from jsonb_array_elements(p->'lines') loop
    v_cost := _post_stock((l->>'product_id')::uuid, v_from, -(l->>'qty')::numeric, null, 'TRF', v_id, v_no, 'Kirim transfer');
    perform _post_stock((l->>'product_id')::uuid, v_transit, (l->>'qty')::numeric, v_cost, 'TRF', v_id, v_no, 'Masuk in-transit');
    insert into transfer_lines(transfer_id, product_id, qty_sent, unit_cost) values (v_id, (l->>'product_id')::uuid, (l->>'qty')::numeric, v_cost);
  end loop;
  return v_id;
end $$;

create or replace function public.transfer_receive(p_id uuid, p_lines jsonb, p_note text) returns text
language plpgsql security definer set search_path = public as $$
declare t stock_transfers; tl transfer_lines; v_transit uuid; v_recv numeric; v_diff_val numeric := 0;
begin
  perform require_perm('transfer','create');
  select * into t from stock_transfers where id = p_id for update;
  if t.status <> 'in_transit' then raise exception 'Transfer % sudah diterima.', t.no; end if;
  perform require_branch(_branch_of_loc(t.to_location_id));
  if t.sent_by = _uid() then raise exception 'Pengirim tidak boleh mengonfirmasi penerimaan transfernya sendiri.'; end if;
  select id into v_transit from stock_locations where kind = 'in_transit' limit 1;
  for tl in select * from transfer_lines where transfer_id = p_id loop
    select (e->>'qty_received')::numeric into v_recv from jsonb_array_elements(p_lines) e where (e->>'line_id')::uuid = tl.id;
    if v_recv is null then raise exception 'Jumlah diterima untuk semua barang wajib diisi (hitung fisik).'; end if;
    if v_recv < 0 or v_recv > tl.qty_sent then raise exception 'Jumlah diterima tidak boleh negatif atau melebihi jumlah kirim.'; end if;
    perform _post_stock(tl.product_id, v_transit, -tl.qty_sent, tl.unit_cost, 'TRF', t.id, t.no, 'Keluar in-transit');
    if v_recv > 0 then
      perform _post_stock(tl.product_id, t.to_location_id, v_recv, tl.unit_cost, 'TRF', t.id, t.no, 'Terima transfer');
    end if;
    update transfer_lines set qty_received = v_recv where id = tl.id;
    v_diff_val := v_diff_val + round((tl.qty_sent - v_recv) * tl.unit_cost, 2);
  end loop;
  update stock_transfers set status = case when v_diff_val > 0 then 'received_diff' else 'received' end,
    received_by = _uid(), received_at = now(), receive_note = p_note, diff_value = v_diff_val where id = p_id;
  if v_diff_val > 0 then
    perform _post_journal(today_jkt(), 'Berita acara selisih transfer ' || t.no, _branch_of_loc(t.to_location_id), 'TRF', t.id,
      jsonb_build_array(jsonb_build_object('a','5102','d',v_diff_val), jsonb_build_object('a','1301','c',v_diff_val)));
    return 'received_diff';
  end if;
  return 'received';
end $$;

create or replace function public.transfer_resolve(p_id uuid, p_responsible text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare t stock_transfers;
begin
  perform require_perm('transfer','approve');
  select * into t from stock_transfers where id = p_id for update;
  if t.status <> 'received_diff' then raise exception 'Tidak ada berita acara selisih terbuka untuk transfer ini.'; end if;
  if length(trim(coalesce(p_responsible,''))) < 3 then raise exception 'Nama penanggung jawab selisih wajib diisi.'; end if;
  update stock_transfers set status = 'resolved', resolved_by = _uid(), resolved_at = now(),
    responsible = p_responsible, resolve_note = p_note where id = p_id;
end $$;

-- stock opname (penuh / cycle count acak) — hitung buta
create or replace function public.opname_create(p_location uuid, p_kind text, p_sample int default 10, p_note text default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform require_perm('opname','create');
  perform require_branch(_branch_of_loc(p_location));
  insert into stock_opnames(no, location_id, kind, note, created_by)
  values (next_no(case when p_kind = 'cycle' then 'CC' else 'OPN' end), p_location, p_kind, p_note, _uid())
  returning id into v_id;
  if p_kind = 'full' then
    insert into opname_lines(opname_id, product_id)
    select v_id, p.id from products p where p.active and p.is_stock
      and (exists(select 1 from stock_balances b where b.product_id = p.id and b.location_id = p_location and b.qty <> 0)
           or p.category in ('barang_jadi','komponen','bahan_baku'));
  else
    -- cycle count: prioritaskan SKU yang sering bergerak 30 hari terakhir, sisanya acak
    insert into opname_lines(opname_id, product_id)
    select v_id, product_id from (
      select b.product_id,
             (select count(*) from stock_ledger sl where sl.product_id = b.product_id and sl.location_id = p_location
                and sl.qty < 0 and sl.at > now() - interval '30 days') as moves
        from stock_balances b where b.location_id = p_location and b.qty > 0
       order by moves desc, random() limit greatest(p_sample,1) * 2) z
    order by random() limit greatest(p_sample,1);
  end if;
  return v_id;
end $$;

create or replace function public.opname_count(p_id uuid, p_lines jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare o stock_opnames; e jsonb;
begin
  perform require_perm('opname','create');
  select * into o from stock_opnames where id = p_id for update;
  if o.status <> 'counting' then raise exception 'Opname sudah diajukan.'; end if;
  perform require_branch(_branch_of_loc(o.location_id));
  for e in select * from jsonb_array_elements(p_lines) loop
    update opname_lines set counted_qty = nullif(e->>'counted_qty','')::numeric
     where id = (e->>'line_id')::uuid and opname_id = p_id;
  end loop;
  update stock_opnames set counted_by = _uid() where id = p_id;
end $$;

create or replace function public.opname_submit(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare o stock_opnames; v_val numeric;
begin
  perform require_perm('opname','create');
  select * into o from stock_opnames where id = p_id for update;
  if o.status <> 'counting' then raise exception 'Opname sudah diajukan.'; end if;
  if exists(select 1 from opname_lines where opname_id = p_id and counted_qty is null) then
    raise exception 'Masih ada barang yang belum dihitung. Isi 0 jika memang tidak ada.';
  end if;
  update opname_lines ol set system_qty = coalesce(b.qty, 0), unit_cost = p.avg_cost
    from products p left join stock_balances b on b.product_id = p.id and b.location_id = o.location_id
   where ol.opname_id = p_id and p.id = ol.product_id;
  select coalesce(sum(round((counted_qty - system_qty) * unit_cost, 2)),0) into v_val from opname_lines where opname_id = p_id;
  update stock_opnames set status = 'submitted', submitted_at = now(), diff_value = v_val,
    counted_by = coalesce(counted_by, _uid()) where id = p_id;
end $$;

create or replace function public.opname_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare o stock_opnames; r record; v_abs numeric; v_adj uuid; v_no text; v_in numeric := 0; v_out numeric := 0;
begin
  perform require_perm('opname','approve');
  select * into o from stock_opnames where id = p_id for update;
  if o.status <> 'submitted' then raise exception 'Opname tidak sedang menunggu approval.'; end if;
  if _uid() in (o.counted_by, o.created_by) then raise exception 'Pemisahan tugas: penghitung/pembuat opname tidak boleh meng-approve selisihnya.'; end if;
  if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Catatan approval wajib diisi.'; end if;
  if not p_approve then
    update stock_opnames set status = 'rejected', approved_by = _uid(), approved_at = now(), approve_note = p_note where id = p_id;
    return;
  end if;
  select coalesce(sum(abs(round((counted_qty - system_qty) * unit_cost, 2))),0) into v_abs from opname_lines where opname_id = p_id;
  if v_abs > setting_num('adj_hq_threshold') and not (has_role('owner') or has_role('area_manager')) then
    raise exception 'Nilai selisih Rp % melebihi batas. Wajib di-approve Area Manager / Owner.', v_abs;
  end if;
  v_no := next_no('ADJ');
  insert into stock_adjustments(no, location_id, reason_code, note, source, source_id, status, total_value, requested_by, decided_by, decided_at, decide_note)
  values (v_no, o.location_id, 'selisih_opname', 'Selisih opname ' || o.no || ': ' || p_note, 'opname', o.id, 'approved', o.diff_value,
          o.counted_by, _uid(), now(), p_note) returning id into v_adj;
  for r in select * from opname_lines where opname_id = p_id and counted_qty <> system_qty loop
    insert into adjustment_lines(adjustment_id, product_id, qty, unit_cost) values (v_adj, r.product_id, r.counted_qty - r.system_qty, r.unit_cost);
    perform _post_stock(r.product_id, o.location_id, r.counted_qty - r.system_qty, r.unit_cost, 'OPN', o.id, o.no, 'Selisih opname', 0, true);
    if r.counted_qty > r.system_qty then v_in := v_in + round((r.counted_qty - r.system_qty) * r.unit_cost, 2);
    else v_out := v_out + round((r.system_qty - r.counted_qty) * r.unit_cost, 2); end if;
  end loop;
  update stock_opnames set status = 'approved', approved_by = _uid(), approved_at = now(), approve_note = p_note where id = p_id;
  perform _post_journal(today_jkt(), 'Selisih opname ' || o.no, _branch_of_loc(o.location_id), 'OPN', o.id, jsonb_build_array(
    jsonb_build_object('a','1301','d',v_in - v_out), jsonb_build_object('a','5102','c',v_in - v_out)));
end $$;

-- penyesuaian stok: reason code + alasan + approval
create or replace function public.adjustment_create(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; l jsonb; v_loc uuid := (p->>'location_id')::uuid; v_reason adjustment_reasons; v_qty numeric; v_cost numeric; v_val numeric := 0;
begin
  perform require_perm('adjustment','create');
  perform require_branch(_branch_of_loc(v_loc));
  select * into v_reason from adjustment_reasons where code = p->>'reason_code';
  if not found then raise exception 'Kode alasan wajib dipilih.'; end if;
  if length(trim(coalesce(p->>'note',''))) < 10 then raise exception 'Keterangan penyesuaian wajib dijelaskan (min. 10 karakter).'; end if;
  if jsonb_array_length(coalesce(p->'lines','[]')) = 0 then raise exception 'Minimal 1 barang.'; end if;
  insert into stock_adjustments(no, location_id, reason_code, note, photo_path, requested_by)
  values (next_no('ADJ'), v_loc, v_reason.code, p->>'note', p->>'photo_path', _uid()) returning id into v_id;
  for l in select * from jsonb_array_elements(p->'lines') loop
    v_qty := (l->>'qty')::numeric;
    if (v_reason.direction = 'in' and v_qty < 0) or (v_reason.direction = 'out' and v_qty > 0) then
      raise exception 'Alasan "%" hanya untuk arah %.', v_reason.name, case v_reason.direction when 'in' then 'tambah' else 'kurang' end;
    end if;
    select coalesce(case when v_qty > 0 then nullif(l->>'unit_cost','')::numeric end, avg_cost) into v_cost from products where id = (l->>'product_id')::uuid;
    insert into adjustment_lines(adjustment_id, product_id, qty, unit_cost) values (v_id, (l->>'product_id')::uuid, v_qty, v_cost);
    v_val := v_val + round(v_qty * v_cost, 2);
  end loop;
  update stock_adjustments set total_value = v_val where id = v_id;
  return v_id;
end $$;

create or replace function public.adjustment_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare a stock_adjustments; r adjustment_lines; v_abs numeric; v_acc text; v_cost numeric;
begin
  perform require_perm('adjustment','approve');
  select * into a from stock_adjustments where id = p_id for update;
  if a.status <> 'pending' then raise exception 'Penyesuaian sudah diputuskan.'; end if;
  if a.requested_by = _uid() then raise exception 'Pemisahan tugas: pengaju tidak boleh menyetujui penyesuaiannya sendiri.'; end if;
  if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Catatan keputusan wajib diisi.'; end if;
  if not p_approve then
    update stock_adjustments set status = 'rejected', decided_by = _uid(), decided_at = now(), decide_note = p_note where id = p_id;
    return;
  end if;
  select coalesce(sum(abs(round(qty*unit_cost,2))),0) into v_abs from adjustment_lines where adjustment_id = p_id;
  if v_abs > setting_num('adj_hq_threshold') and not (has_role('owner') or has_role('area_manager')) then
    raise exception 'Nilai penyesuaian Rp % melebihi batas. Wajib di-approve Area Manager / Owner.', v_abs;
  end if;
  for r in select * from adjustment_lines where adjustment_id = p_id loop
    if r.qty > 0 then perform _apply_avg(r.product_id, r.qty, r.unit_cost, a.no); end if;
    v_cost := _post_stock(r.product_id, a.location_id, r.qty, case when r.qty > 0 then r.unit_cost end, 'ADJ', a.id, a.no, a.reason_code);
    if r.qty < 0 and v_cost <> r.unit_cost then
      update adjustment_lines set unit_cost = v_cost where id = r.id;   -- nilai aktual saat posting (moving average)
    end if;
  end loop;
  select coalesce(sum(round(qty*unit_cost,2)),0) into v_abs from adjustment_lines where adjustment_id = p_id;
  select account_code into v_acc from adjustment_reasons where code = a.reason_code;
  update stock_adjustments set status = 'approved', decided_by = _uid(), decided_at = now(), decide_note = p_note, total_value = v_abs where id = p_id;
  perform _post_journal(today_jkt(), 'Penyesuaian ' || a.no, _branch_of_loc(a.location_id), 'ADJ', a.id, jsonb_build_array(
    jsonb_build_object('a','1301','d',v_abs), jsonb_build_object('a',v_acc,'c',v_abs)));
end $$;

create or replace function public.allocation_set(p_product uuid, p_location uuid, p_channel uuid, p_qty numeric) returns void
language plpgsql security definer set search_path = public as $$
declare v_other numeric; v_bal numeric;
begin
  perform require_perm('allocation','edit');
  perform require_branch(_branch_of_loc(p_location));
  if p_qty < 0 then raise exception 'Jumlah alokasi tidak boleh negatif.'; end if;
  select coalesce(sum(qty),0) into v_other from channel_allocations where product_id = p_product and location_id = p_location and channel_id <> p_channel;
  select coalesce(qty - reserved,0) into v_bal from stock_balances where product_id = p_product and location_id = p_location;
  if v_other + p_qty > coalesce(v_bal,0) then
    raise exception 'Total alokasi (%) melebihi stok tersedia (%).', v_other + p_qty, coalesce(v_bal,0);
  end if;
  insert into channel_allocations(product_id, location_id, channel_id, qty, updated_by) values (p_product, p_location, p_channel, p_qty, _uid())
  on conflict (product_id, location_id, channel_id) do update set qty = excluded.qty, updated_at = now(), updated_by = excluded.updated_by;
end $$;
-- =====================================================================
--  RPC: PENJUALAN (Sales Order, Penawaran, POS, Void)
-- =====================================================================
create or replace function public._so_fill_lines(p_so uuid, p_lines jsonb, p_tier text, p_allow_custom boolean)
returns jsonb language plpgsql security definer set search_path = public as $$
declare l jsonb; v_prod products; v_list numeric; v_price numeric; v_qty numeric;
        v_sub numeric := 0; v_gross numeric := 0; v_custom boolean := false; v_serials text[];
begin
  if jsonb_array_length(coalesce(p_lines,'[]')) = 0 then raise exception 'Pesanan minimal berisi 1 barang/jasa.'; end if;
  for l in select * from jsonb_array_elements(p_lines) loop
    select * into v_prod from products where id = (l->>'product_id')::uuid and active;
    if not found then raise exception 'Produk tidak ditemukan atau nonaktif.'; end if;
    v_qty := (l->>'qty')::numeric;
    if v_qty is null or v_qty <= 0 then raise exception 'Jumlah % harus lebih dari 0.', v_prod.sku; end if;
    if not p_allow_custom and v_prod.category in ('piala_rakitan','akrilik_custom') then
      raise exception '% adalah produk custom — buat lewat Sales Order agar ada desain & perintah kerja.', v_prod.name;
    end if;
    v_list := case p_tier when 'reseller' then nullif(v_prod.price_reseller,0) when 'instansi' then nullif(v_prod.price_instansi,0) end;
    v_list := coalesce(v_list, v_prod.price_retail);
    v_price := coalesce(nullif(l->>'price','')::numeric, v_list);
    if v_price < 0 then raise exception 'Harga tidak boleh negatif.'; end if;
    select array_agg(x) into v_serials from jsonb_array_elements_text(coalesce(l->'serials','[]')) x;
    insert into so_lines(so_id, product_id, qty, list_price, price, engraving_text, is_custom, serials)
    values (p_so, v_prod.id, v_qty, v_list, v_price, nullif(l->>'engraving_text',''),
            v_prod.category in ('piala_rakitan','akrilik_custom'), v_serials);
    v_sub := v_sub + round(v_qty * v_price, 2);
    v_gross := v_gross + round(v_qty * v_list, 2);
    if v_prod.category in ('piala_rakitan','akrilik_custom') then v_custom := true; end if;
  end loop;
  return jsonb_build_object('sub', v_sub, 'gross', v_gross, 'custom', v_custom);
end $$;

create or replace function public.so_save(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid := nullif(p->>'id','')::uuid; s sales_orders; v_ch sales_channels; v_branch uuid := (p->>'branch_id')::uuid;
        v_loc uuid; v_kind text := coalesce(p->>'kind','order'); v_tier text := coalesce(p->>'price_tier','retail');
        r jsonb; v_disc numeric := coalesce(nullif(p->>'discount_amount','')::numeric, 0);
        v_ship numeric := coalesce(nullif(p->>'shipping_charge','')::numeric, 0); v_total numeric; v_fee numeric; v_dp numeric; v_min_dp numeric;
        v_cust customers;
begin
  perform require_perm('sales','create');
  perform require_branch(v_branch);
  select * into v_ch from sales_channels where id = nullif(p->>'channel_id','')::uuid and active;
  if not found then raise exception 'Channel penjualan wajib dipilih.'; end if;
  if coalesce(trim(p->>'customer_name'),'') = '' then raise exception 'Nama pelanggan wajib diisi.'; end if;
  if length(regexp_replace(coalesce(p->>'customer_phone',''), '\D', '', 'g')) < 8 then
    raise exception 'Nomor kontak pelanggan wajib diisi (minimal 8 digit).';
  end if;
  if nullif(p->>'customer_id','') is not null then select * into v_cust from customers where id = (p->>'customer_id')::uuid; end if;
  v_loc := coalesce(nullif(p->>'location_id','')::uuid, _loc_of_kind(v_branch, 'main'));
  if v_id is null then
    insert into sales_orders(no, kind, channel_id, branch_id, location_id, customer_name, status, created_by)
    values (next_no(case when v_kind = 'quotation' then 'QUO' else 'SO' end), v_kind, v_ch.id, v_branch, v_loc, p->>'customer_name',
            case when v_kind = 'quotation' then 'quotation' else 'draft' end, _uid())
    returning id into v_id;
  else
    select * into s from sales_orders where id = v_id for update;
    if s.status not in ('draft','quotation') then raise exception 'Pesanan % sudah dikonfirmasi, tidak bisa diubah.', s.no; end if;
    if s.created_by <> _uid() and not has_perm('sales','edit') then raise exception 'Hanya pembuat yang boleh mengubah draft ini.'; end if;
    perform set_config('erp.allow_draft_rewrite','on',true);
    delete from so_lines where so_id = v_id;
    perform set_config('erp.allow_draft_rewrite','off',true);
  end if;
  r := _so_fill_lines(v_id, p->'lines', v_tier, true);
  if v_disc < 0 or v_disc > (r->>'sub')::numeric then raise exception 'Diskon nota tidak valid.'; end if;
  v_total := (r->>'sub')::numeric - v_disc + v_ship;
  v_fee := coalesce(nullif(p->>'channel_fee','')::numeric, round((r->>'sub')::numeric * v_ch.admin_fee_pct / 100, 0));
  v_min_dp := case when (r->>'custom')::boolean and v_ch.kind <> 'marketplace' and coalesce(v_cust.credit_limit,0) = 0
                   then round(v_total * setting_num('dp_min_pct') / 100, 0) else 0 end;
  v_dp := greatest(coalesce(nullif(p->>'dp_required','')::numeric, v_min_dp), 0);
  if v_dp < v_min_dp then raise exception 'DP minimum untuk pesanan custom adalah Rp %.', v_min_dp; end if;
  if v_dp > v_total then v_dp := v_total; end if;
  update sales_orders set
    channel_id = v_ch.id, branch_id = v_branch, location_id = v_loc,
    customer_id = nullif(p->>'customer_id','')::uuid, customer_name = trim(p->>'customer_name'), customer_phone = trim(p->>'customer_phone'),
    price_tier = v_tier, need_date = nullif(p->>'need_date','')::date, spec_note = p->>'spec_note',
    marketplace_order_no = nullif(trim(p->>'marketplace_order_no'),''), note = p->>'note',
    subtotal = (r->>'sub')::numeric, gross_list = (r->>'gross')::numeric, discount_amount = v_disc, shipping_charge = v_ship,
    total = v_total, channel_fee = v_fee, voucher_seller = coalesce(nullif(p->>'voucher_seller','')::numeric, 0), dp_required = v_dp,
    discount_pct = case when (r->>'gross')::numeric > 0
                        then round(((r->>'gross')::numeric - ((r->>'sub')::numeric - v_disc)) / (r->>'gross')::numeric * 100, 2) else 0 end,
    discount_status = 'none', credit_status = 'none', updated_at = now()
  where id = v_id;
  return v_id;
end $$;

create or replace function public.so_confirm(p_id uuid) returns text
language plpgsql security definer set search_path = public as $$
declare s sales_orders; c customers; l so_lines; v_prod products; v_open numeric := 0; v_bad boolean := false;
        v_take numeric; v_free numeric; v_has_wo boolean := false;
begin
  perform require_perm('sales','create');
  select * into s from sales_orders where id = p_id for update;
  perform require_branch(s.branch_id);
  if s.status not in ('draft','quotation') then raise exception 'Pesanan % sudah dikonfirmasi.', s.no; end if;
  if s.kind = 'pos' then raise exception 'Transaksi POS diselesaikan dari layar kasir.'; end if;

  -- 1) batas diskon per jabatan
  if s.discount_pct > my_discount_limit() and s.discount_status <> 'approved' then
    update sales_orders set discount_status = 'pending' where id = p_id;
    return 'pending_discount';
  end if;
  -- 2) limit kredit & tagihan macet
  if s.customer_id is not null then
    select * into c from customers where id = s.customer_id;
    if c.blocked then raise exception 'Pelanggan % sedang diblokir. Hubungi keuangan.', c.name; end if;
    select coalesce(sum(_outstanding(x)),0), coalesce(bool_or(x.due_date < today_jkt() - setting_num('bad_debt_days')::int and _outstanding(x) > 0), false)
      into v_open, v_bad
      from sales_orders x where x.customer_id = s.customer_id and x.recognized_at is not null and x.status not in ('void','cancelled');
    if (c.credit_limit > 0 and v_open + s.total - s.dp_required > c.credit_limit) or v_bad then
      if s.credit_status <> 'approved' then
        update sales_orders set credit_status = 'pending' where id = p_id;
        return 'pending_credit';
      end if;
    end if;
  end if;

  if s.status = 'quotation' then
    update sales_orders set kind = 'order', note = trim(coalesce(note,'') || ' [dari penawaran ' || s.no || ']'),
                            no = next_no('SO') where id = p_id;
  end if;

  -- 3) reservasi stok barang jadi & perintah kerja untuk produk custom
  for l in select * from so_lines where so_id = p_id loop
    select * into v_prod from products where id = l.product_id;
    if l.is_custom then
      insert into work_orders(no, so_id, so_line_id, product_id, qty, location_id, status, spec, target_date, created_by)
      values (next_no('WO'), s.id, l.id, l.product_id, l.qty, s.location_id,
              case when v_prod.requires_design then 'waiting_design' else 'ready' end,
              nullif(trim(coalesce(l.engraving_text,'') || E'\n' || coalesce(s.spec_note,'')), ''), s.need_date, _uid());
      v_has_wo := true;
    elsif v_prod.is_stock then
      v_free := _free_qty(l.product_id, s.location_id, s.channel_id);
      if v_free < l.qty then
        raise exception 'Stok % tidak cukup untuk dipesan (bebas %, butuh %).', v_prod.sku, v_free, l.qty;
      end if;
      select least(coalesce(sum(qty),0), l.qty) into v_take from channel_allocations
       where product_id = l.product_id and location_id = s.location_id and channel_id = s.channel_id;
      if v_take > 0 then
        update channel_allocations set qty = qty - v_take, updated_at = now()
         where product_id = l.product_id and location_id = s.location_id and channel_id = s.channel_id;
      end if;
      perform _reserve(l.product_id, s.location_id, l.qty);
      update so_lines set reserved_qty = l.qty where id = l.id;
    end if;
  end loop;
  update sales_orders set status = case when v_has_wo then 'in_production' else 'ready' end, updated_at = now() where id = p_id;
  return case when v_has_wo then 'in_production' else 'ready' end;
end $$;

create or replace function public.so_approve(p_id uuid, p_kind text, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare s sales_orders;
begin
  perform require_perm('sales','approve');
  select * into s from sales_orders where id = p_id for update;
  if s.created_by = _uid() then raise exception 'Pemisahan tugas: pembuat transaksi tidak boleh menyetujui sendiri.'; end if;
  if length(trim(coalesce(p_note,''))) < 3 then raise exception 'Catatan approval wajib diisi.'; end if;
  if p_kind = 'discount' then
    if s.discount_status <> 'pending' then raise exception 'Tidak ada diskon yang menunggu approval.'; end if;
    if p_approve and s.discount_pct > my_discount_limit() then
      raise exception 'Diskon % persen melebihi batas jabatan Anda (% persen).', s.discount_pct, my_discount_limit();
    end if;
    update sales_orders set discount_status = case when p_approve then 'approved' else 'rejected' end,
      approval_by = _uid(), approval_note = p_note where id = p_id;
  elsif p_kind = 'credit' then
    if s.credit_status <> 'pending' then raise exception 'Tidak ada pengecualian kredit yang menunggu approval.'; end if;
    if not (has_role('owner') or has_role('finance_manager') or has_role('area_manager')) then
      raise exception 'Pengecualian limit kredit hanya oleh Owner, Manajer Keuangan, atau Area Manager.';
    end if;
    update sales_orders set credit_status = case when p_approve then 'approved' else 'rejected' end,
      approval_by = _uid(), approval_note = p_note where id = p_id;
  else
    raise exception 'Jenis approval tidak dikenal.';
  end if;
end $$;

-- ---------- POS ----------
create or replace function public._open_session(p_branch uuid) returns uuid
language sql stable security definer set search_path = public as $$
  select id from cash_sessions where branch_id = p_branch and opened_by = auth.uid() and status = 'open' order by opened_at desc limit 1
$$;

create or replace function public._insert_payment(s sales_orders, p jsonb, p_session uuid, p_settlement uuid default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_method text := p->>'method'; v_amt numeric := (p->>'amount')::numeric; v_no text;
begin
  if v_amt is null or v_amt <= 0 then raise exception 'Nominal pembayaran harus lebih dari 0.'; end if;
  if v_method not in ('cash','transfer','qris','edc','marketplace') then raise exception 'Metode bayar tidak dikenal.'; end if;
  if v_method <> 'cash' then
    if not exists(select 1 from bank_accounts where id = nullif(p->>'bank_account_id','')::uuid and active) then
      raise exception 'Pilih rekening perusahaan yang terdaftar. Pembayaran ke rekening lain tidak diakui.';
    end if;
    if coalesce(p->>'proof_path','') = '' and v_method <> 'marketplace' then
      raise exception 'Bukti pembayaran (transfer/QRIS/struk EDC) wajib diunggah.';
    end if;
  elsif p_session is null then
    raise exception 'Pembayaran tunai hanya lewat sesi kas yang sedang dibuka.';
  end if;
  v_no := next_no('PAY');
  insert into payments(no, so_id, branch_id, amount, method, bank_account_id, proof_path, pay_date, status, note, cash_session_id,
                       settlement_id, created_by, verified_by, verified_at, verify_note)
  values (v_no, s.id, s.branch_id, v_amt, v_method, nullif(p->>'bank_account_id','')::uuid, nullif(p->>'proof_path',''),
          coalesce(nullif(p->>'pay_date','')::date, today_jkt()),
          case when v_method = 'cash' or p_settlement is not null then 'verified' else 'pending' end,
          p->>'note', case when v_method = 'cash' then p_session end, p_settlement, _uid(),
          case when v_method = 'cash' or p_settlement is not null then _uid() end,
          case when v_method = 'cash' or p_settlement is not null then now() end,
          case when v_method = 'cash' then 'Tunai masuk sesi kas' when p_settlement is not null then 'Settlement marketplace' end)
  returning id into v_id;
  if v_method = 'cash' then
    update sales_orders set paid_verified = paid_verified + v_amt where id = s.id;
    perform _post_journal(today_jkt(), 'Terima tunai ' || v_no || ' / ' || s.no, s.branch_id, 'PAY', v_id, jsonb_build_array(
      jsonb_build_object('a','1101','d',v_amt),
      jsonb_build_object('a', case when (select recognized_at from sales_orders where id = s.id) is null then '2201' else '1201' end, 'c', v_amt)));
  end if;
  return v_id;
end $$;

create or replace function public._pos_complete(p_so uuid, p_payments jsonb, p_session uuid) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sales_orders; l so_lines; v_prod products; v_cost numeric; v_free numeric; v_sum numeric := 0; e jsonb; sr text; v_su serial_units;
begin
  select * into s from sales_orders where id = p_so for update;
  select coalesce(sum((x->>'amount')::numeric),0) into v_sum from jsonb_array_elements(coalesce(p_payments,'[]')) x;
  if round(v_sum,2) <> round(s.total,2) then
    raise exception 'Total pembayaran Rp % harus sama dengan total belanja Rp %.', v_sum, s.total;
  end if;
  for l in select * from so_lines where so_id = p_so loop
    select * into v_prod from products where id = l.product_id;
    if not v_prod.is_stock then continue; end if;
    v_free := _free_qty(l.product_id, s.location_id, s.channel_id);
    if v_free < l.qty then
      raise exception 'Stok % tidak cukup/sedang dialokasikan ke channel online (bebas %).', v_prod.sku, v_free;
    end if;
    if v_prod.track_serial then
      if coalesce(array_length(l.serials,1),0) <> l.qty then
        raise exception '% wajib discan serial/QR per unit (% unit).', v_prod.name, l.qty;
      end if;
      foreach sr in array l.serials loop
        select * into v_su from serial_units where serial = sr and product_id = l.product_id for update;
        if not found or v_su.status <> 'in_stock' or v_su.location_id <> s.location_id then
          raise exception 'Serial % tidak tersedia di lokasi ini.', sr;
        end if;
        v_cost := _post_stock(l.product_id, s.location_id, -1, null, 'POS', s.id, s.no, 'Penjualan kasir', 0, false, sr);
        update serial_units set status = 'sold', last_doc_no = s.no, updated_at = now() where id = v_su.id;
      end loop;
    else
      v_cost := _post_stock(l.product_id, s.location_id, -l.qty, null, 'POS', s.id, s.no, 'Penjualan kasir');
    end if;
    update so_lines set unit_cost = v_cost where id = l.id;
  end loop;
  update sales_orders set status = 'completed', updated_at = now() where id = p_so;
  perform _recognize_so(p_so);
  select * into s from sales_orders where id = p_so;
  for e in select * from jsonb_array_elements(coalesce(p_payments,'[]')) loop
    perform _insert_payment(s, e, p_session);
  end loop;
  return jsonb_build_object('so_id', s.id, 'no', s.no, 'status', 'completed');
end $$;

create or replace function public.pos_checkout(p jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_branch uuid := (p->>'branch_id')::uuid; v_sess uuid; v_ch uuid; v_id uuid; r jsonb; v_disc numeric := coalesce(nullif(p->>'discount_amount','')::numeric,0);
        v_pct numeric; v_tier text := coalesce(p->>'price_tier','retail');
begin
  perform require_perm('pos','create');
  perform require_branch(v_branch);
  v_sess := _open_session(v_branch);
  if v_sess is null then raise exception 'Buka sesi kas terlebih dahulu sebelum berjualan.'; end if;
  v_ch := coalesce(nullif(p->>'channel_id','')::uuid, (select id from sales_channels where code = 'WALKIN'));
  insert into sales_orders(no, kind, channel_id, branch_id, location_id, customer_id, customer_name, customer_phone, price_tier, status, note, created_by)
  values (next_no('POS'), 'pos', v_ch, v_branch, coalesce(nullif(p->>'location_id','')::uuid, _loc_of_kind(v_branch,'main')),
          nullif(p->>'customer_id','')::uuid, coalesce(nullif(trim(p->>'customer_name'),''), 'Pelanggan umum'),
          nullif(trim(p->>'customer_phone'),''), v_tier, 'draft', p->>'note', _uid())
  returning id into v_id;
  r := _so_fill_lines(v_id, p->'lines', v_tier, false);
  if v_disc < 0 or v_disc > (r->>'sub')::numeric then raise exception 'Diskon tidak valid.'; end if;
  v_pct := case when (r->>'gross')::numeric > 0 then round(((r->>'gross')::numeric - ((r->>'sub')::numeric - v_disc)) / (r->>'gross')::numeric * 100, 2) else 0 end;
  update sales_orders set subtotal = (r->>'sub')::numeric, gross_list = (r->>'gross')::numeric, discount_amount = v_disc,
    total = (r->>'sub')::numeric - v_disc, discount_pct = v_pct,
    discount_status = case when v_pct > my_discount_limit() then 'pending' else 'none' end
  where id = v_id;
  if v_pct > my_discount_limit() then
    return jsonb_build_object('so_id', v_id, 'no', (select no from sales_orders where id = v_id), 'status', 'pending_discount');
  end if;
  return _pos_complete(v_id, p->'payments', v_sess);
end $$;

create or replace function public.pos_complete(p_so uuid, p_payments jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare s sales_orders; v_sess uuid;
begin
  perform require_perm('pos','create');
  select * into s from sales_orders where id = p_so;
  if s.kind <> 'pos' or s.status <> 'draft' then raise exception 'Transaksi tidak dalam status tertahan.'; end if;
  if s.discount_status = 'pending' then raise exception 'Diskon masih menunggu approval.'; end if;
  if s.discount_status = 'rejected' then raise exception 'Diskon ditolak. Batalkan transaksi ini lalu input ulang.'; end if;
  v_sess := _open_session(s.branch_id);
  if v_sess is null then raise exception 'Buka sesi kas terlebih dahulu.'; end if;
  return _pos_complete(p_so, p_payments, v_sess);
end $$;

-- ---------- Void / batal: selalu dengan alasan + approval, tidak menghapus ----------
create or replace function public.so_void_request(p_id uuid, p_reason text) returns text
language plpgsql security definer set search_path = public as $$
declare s sales_orders;
begin
  if not (has_perm('sales','create') or has_perm('pos','create')) then raise exception 'Akses ditolak.'; end if;
  select * into s from sales_orders where id = p_id for update;
  perform require_branch(s.branch_id);
  if length(trim(coalesce(p_reason,''))) < 10 then raise exception 'Alasan void/batal wajib dijelaskan (min. 10 karakter).'; end if;
  if s.status in ('void','cancelled') then raise exception 'Transaksi sudah dibatalkan.'; end if;
  if s.status in ('shipped') or (s.status = 'completed' and s.kind <> 'pos') then
    raise exception 'Barang sudah diserahkan. Gunakan menu Retur, bukan void.';
  end if;
  -- draft/penawaran belum berdampak stok & uang: batal langsung, tetap tercatat
  if s.status in ('draft','quotation') and not exists(select 1 from payments where so_id = p_id and status in ('pending','verified')) then
    update sales_orders set status = 'cancelled', void_reason = p_reason, void_requested_by = _uid(), void_status = 'approved',
      void_decided_by = _uid(), void_decided_at = now(), updated_at = now() where id = p_id;
    return 'cancelled';
  end if;
  if s.void_status = 'pending' then raise exception 'Permintaan void sudah diajukan.'; end if;
  update sales_orders set void_status = 'pending', void_reason = p_reason, void_requested_by = _uid(), updated_at = now() where id = p_id;
  return 'pending';
end $$;

create or replace function public.so_void_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare s sales_orders; l so_lines; p payments; sr text; v_sess cash_sessions;
begin
  perform require_perm('sales','approve');
  select * into s from sales_orders where id = p_id for update;
  if s.void_status <> 'pending' then raise exception 'Tidak ada permintaan void yang menunggu.'; end if;
  if _uid() in (s.void_requested_by, s.created_by) then raise exception 'Pemisahan tugas: void harus disetujui orang lain.'; end if;
  if length(trim(coalesce(p_note,''))) < 3 then raise exception 'Catatan keputusan wajib diisi.'; end if;
  if not p_approve then
    update sales_orders set void_status = 'rejected', void_decided_by = _uid(), void_decided_at = now(),
      approval_note = p_note, updated_at = now() where id = p_id;
    return;
  end if;

  if s.kind = 'pos' and s.status = 'completed' then
    -- void POS: hanya selama sesi kas masih terbuka
    for p in select * from payments where so_id = p_id and status in ('verified','pending') loop
      if p.method = 'cash' then
        select * into v_sess from cash_sessions where id = p.cash_session_id;
        if v_sess.status <> 'open' then raise exception 'Sesi kas % sudah ditutup. Gunakan menu Retur.', v_sess.no; end if;
      end if;
    end loop;
    for l in select * from so_lines where so_id = p_id loop
      if l.serials is not null and array_length(l.serials,1) > 0 then
        foreach sr in array l.serials loop
          perform _post_stock(l.product_id, s.location_id, 1, l.unit_cost, 'VOID', s.id, s.no, 'Void penjualan', 0, false, sr);
          update serial_units set status = 'in_stock', location_id = s.location_id, last_doc_no = s.no || '-VOID', updated_at = now() where serial = sr;
        end loop;
      else
        perform _post_stock(l.product_id, s.location_id, l.qty, l.unit_cost, 'VOID', s.id, s.no, 'Void penjualan');
      end if;
    end loop;
    for p in select * from payments where so_id = p_id and status in ('verified','pending') loop
      perform _reverse_journals(p.id, 'Void ' || s.no);
      update payments set status = 'void', verify_note = coalesce(verify_note,'') || ' [void ' || s.no || ']' where id = p.id;
    end loop;
    perform _reverse_journals(s.id, 'Void ' || s.no);
    update sales_orders set status = 'void', paid_verified = 0, void_status = 'approved', void_decided_by = _uid(),
      void_decided_at = now(), approval_note = p_note, updated_at = now() where id = p_id;
    return;
  end if;

  -- pembatalan pesanan yang belum diserahkan
  if exists(select 1 from payments where so_id = p_id and status = 'verified') then
    raise exception 'Pesanan punya pembayaran terverifikasi. Selesaikan pengembalian dana bersama keuangan sebelum membatalkan.';
  end if;
  if exists(select 1 from payments where so_id = p_id and status = 'pending') then
    raise exception 'Masih ada bukti bayar menunggu verifikasi. Minta keuangan menolak/memverifikasi dulu.';
  end if;
  if exists(select 1 from work_orders where so_id = p_id and status in ('in_progress','qc','done')) then
    raise exception 'Perintah kerja sudah dikerjakan. Catat scrap/hasil produksi dulu, lalu hubungi Kepala Produksi.';
  end if;
  update work_orders set status = 'cancelled' where so_id = p_id and status not in ('done','cancelled');
  for l in select * from so_lines where so_id = p_id and reserved_qty > 0 loop
    perform _unreserve(l.product_id, s.location_id, l.reserved_qty);
    update so_lines set reserved_qty = 0 where id = l.id;
  end loop;
  update sales_orders set status = 'cancelled', void_status = 'approved', void_decided_by = _uid(), void_decided_at = now(),
    approval_note = p_note, updated_at = now() where id = p_id;
end $$;

-- ---------- import pesanan marketplace (CSV) ----------
create or replace function public.mp_import(p_channel uuid, p_branch uuid, p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare o record; v_id uuid; v_ok int := 0; v_skip int := 0; v_err jsonb := '[]'; v_lines jsonb; v_status text;
begin
  perform require_perm('sales','create');
  perform require_branch(p_branch);
  for o in
    select r->>'order_no' order_no, max(r->>'customer_name') customer_name, max(r->>'customer_phone') customer_phone,
           sum(coalesce(nullif(r->>'admin_fee','')::numeric,0)) admin_fee, sum(coalesce(nullif(r->>'voucher','')::numeric,0)) voucher,
           sum(coalesce(nullif(r->>'shipping_charge','')::numeric,0)) shipping, jsonb_agg(r) items
      from jsonb_array_elements(p_rows) r group by r->>'order_no'
  loop
    if exists(select 1 from sales_orders where channel_id = p_channel and marketplace_order_no = o.order_no) then
      v_skip := v_skip + 1; continue;
    end if;
    begin
      select jsonb_agg(jsonb_build_object('product_id', pr.id, 'qty', (i->>'qty')::numeric, 'price', nullif(i->>'price','')))
        into v_lines
        from jsonb_array_elements(o.items) i left join products pr on pr.sku = trim(i->>'sku');
      if exists(select 1 from jsonb_array_elements(v_lines) x where x->>'product_id' is null) then
        raise exception 'SKU tidak dikenal';
      end if;
      v_id := so_save(jsonb_build_object('kind','order','channel_id',p_channel,'branch_id',p_branch,
        'customer_name', coalesce(nullif(o.customer_name,''),'Pembeli ' || o.order_no),
        'customer_phone', coalesce(nullif(o.customer_phone,''),'00000000'),
        'marketplace_order_no', o.order_no, 'channel_fee', nullif(o.admin_fee,0), 'voucher_seller', o.voucher,
        'shipping_charge', o.shipping, 'lines', v_lines));
      v_status := so_confirm(v_id);
      v_ok := v_ok + 1;
    exception when others then
      v_err := v_err || jsonb_build_object('order_no', o.order_no, 'error', sqlerrm);
    end;
  end loop;
  return jsonb_build_object('imported', v_ok, 'skipped', v_skip, 'errors', v_err);
end $$;

-- =====================================================================
--  RPC: PRODUKSI
-- =====================================================================
create or replace function public.design_upload(p_so uuid, p_file text, p_note text) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_ver int; s sales_orders;
begin
  perform require_perm('design','create');
  select * into s from sales_orders where id = p_so;
  perform require_branch(s.branch_id);
  if coalesce(p_file,'') = '' then raise exception 'File mockup wajib diunggah.'; end if;
  select coalesce(max(version),0) + 1 into v_ver from design_approvals where so_id = p_so;
  update design_approvals set status = 'rejected', customer_note = coalesce(customer_note,'') || ' [digantikan versi ' || v_ver || ']'
   where so_id = p_so and status = 'pending';
  insert into design_approvals(so_id, version, file_path, note, created_by) values (p_so, v_ver, p_file, p_note, _uid()) returning id into v_id;
  update work_orders set status = 'waiting_approval' where so_id = p_so and status in ('waiting_design','waiting_approval');
  return v_id;
end $$;

create or replace function public.design_decide(p_id uuid, p_approve boolean, p_proof text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare d design_approvals;
begin
  perform require_perm('design','edit');
  select * into d from design_approvals where id = p_id for update;
  if d.status <> 'pending' then raise exception 'Mockup ini sudah diputuskan.'; end if;
  if p_approve and coalesce(p_proof,'') = '' then
    raise exception 'Unggah bukti persetujuan pelanggan (tangkapan layar chat/email/tanda tangan).';
  end if;
  update design_approvals set status = case when p_approve then 'approved' else 'rejected' end,
    customer_proof_path = p_proof, customer_note = p_note, decided_by = _uid(), decided_at = now() where id = p_id;
  update work_orders set status = case when p_approve then 'ready' else 'waiting_design' end
   where so_id = d.so_id and status = 'waiting_approval';
end $$;

create or replace function public.wo_assign(p_id uuid, p_user uuid, p_target date) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_perm('production','edit');
  update work_orders set assigned_to = p_user, target_date = coalesce(p_target, target_date) where id = p_id and status not in ('done','cancelled');
end $$;

create or replace function public.wo_start(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare w work_orders; s sales_orders;
begin
  perform require_perm('production','edit');
  select * into w from work_orders where id = p_id for update;
  perform require_branch(_branch_of_loc(w.location_id));
  if w.status <> 'ready' then raise exception 'WO belum siap dikerjakan (status: %).', w.status; end if;
  if w.so_id is not null then
    select * into s from sales_orders where id = w.so_id;
    if s.paid_verified < s.dp_required then
      raise exception 'DP belum terverifikasi keuangan (Rp % dari Rp %). Produksi belum boleh dimulai.', s.paid_verified, s.dp_required;
    end if;
  end if;
  update work_orders set status = 'in_progress', started_at = now(), assigned_to = coalesce(assigned_to, _uid()) where id = p_id;
end $$;

create or replace function public.wo_consume(p_id uuid, p_lines jsonb) returns numeric
language plpgsql security definer set search_path = public as $$
declare w work_orders; e record; v_cost numeric; v_val numeric := 0; v_no text;
begin
  perform require_perm('production','edit');
  select * into w from work_orders where id = p_id for update;
  if w.status <> 'in_progress' then raise exception 'Konsumsi bahan hanya saat WO sedang dikerjakan.'; end if;
  for e in
    select (x->>'product_id')::uuid product_id, (x->>'qty')::numeric qty from jsonb_array_elements(coalesce(p_lines,'[]')) x
    union all
    select b.component_id, b.qty * w.qty from bom_lines b where b.product_id = w.product_id and jsonb_array_length(coalesce(p_lines,'[]')) = 0
  loop
    continue when coalesce(e.qty,0) <= 0;
    v_cost := _post_stock(e.product_id, w.location_id, -e.qty, null, 'WO', w.id, w.no, 'Konsumsi bahan produksi');
    insert into wo_consumptions(wo_id, product_id, qty, unit_cost, created_by) values (w.id, e.product_id, e.qty, v_cost, _uid());
    v_val := v_val + round(e.qty * v_cost, 2);
  end loop;
  if v_val = 0 and not exists(select 1 from wo_consumptions where wo_id = p_id) then
    raise exception 'Tidak ada bahan yang dicatat. Isi daftar bahan atau lengkapi BOM produk.';
  end if;
  update work_orders set material_cost = material_cost + v_val where id = p_id;
  perform _post_journal(today_jkt(), 'Konsumsi bahan ' || w.no, _branch_of_loc(w.location_id), 'WO', w.id, jsonb_build_array(
    jsonb_build_object('a','1302','d',v_val), jsonb_build_object('a','1301','c',v_val)));
  return v_val;
end $$;

create or replace function public.wo_scrap(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare w work_orders; v_cost numeric; v_id uuid; v_qty numeric := (p->>'qty')::numeric; v_scrap_loc uuid; v_val numeric;
begin
  perform require_perm('production','edit');
  select * into w from work_orders where id = (p->>'wo_id')::uuid for update;
  if w.status not in ('in_progress','qc') then raise exception 'Scrap dicatat saat WO dikerjakan atau QC.'; end if;
  if coalesce(p->>'photo_path','') = '' then raise exception 'Foto barang gagal/scrap wajib diunggah.'; end if;
  if p->>'cause' = 'lainnya' and length(trim(coalesce(p->>'note',''))) < 10 then raise exception 'Penyebab "lainnya" wajib dijelaskan.'; end if;
  v_scrap_loc := _loc_of_kind(_branch_of_loc(w.location_id), 'scrap');
  v_cost := _post_stock((p->>'product_id')::uuid, w.location_id, -v_qty, null, 'SCRAP', w.id, w.no, 'Gagal produksi: ' || (p->>'cause'));
  perform _post_stock((p->>'product_id')::uuid, v_scrap_loc, v_qty, v_cost, 'SCRAP', w.id, w.no, 'Masuk lokasi scrap');
  insert into wo_scraps(wo_id, product_id, qty, cause, note, operator_id, photo_path, unit_cost, created_by)
  values (w.id, (p->>'product_id')::uuid, v_qty, p->>'cause', p->>'note', coalesce(nullif(p->>'operator_id','')::uuid, w.assigned_to, _uid()),
          p->>'photo_path', v_cost, _uid()) returning id into v_id;
  v_val := round(v_qty * v_cost, 2);
  update work_orders set scrap_cost = scrap_cost + v_val where id = w.id;
  perform _post_journal(today_jkt(), 'Scrap ' || w.no, _branch_of_loc(w.location_id), 'SCRAP', v_id, jsonb_build_array(
    jsonb_build_object('a','5104','d',v_val), jsonb_build_object('a','1301','c',v_val)));
  return v_id;
end $$;

create or replace function public.wo_offcut(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare w work_orders; v_id uuid;
begin
  perform require_perm('production','edit');
  select * into w from work_orders where id = nullif(p->>'wo_id','')::uuid;
  insert into offcuts(no, material_id, width_mm, height_mm, location_id, source_wo_id, note, created_by)
  values (next_no('OFC'), (p->>'material_id')::uuid, (p->>'width_mm')::numeric, (p->>'height_mm')::numeric,
          _loc_of_kind(coalesce(_branch_of_loc(w.location_id), (p->>'branch_id')::uuid), 'offcut'), w.id, p->>'note', _uid())
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.offcut_set_status(p_id uuid, p_status text, p_wo uuid, p_note text) returns void
language plpgsql security definer set search_path = public as $$
begin
  if p_status = 'scrapped' then perform require_perm('production','approve');
    if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Alasan pembuangan sisa bahan wajib diisi.'; end if;
  else perform require_perm('production','edit'); end if;
  update offcuts set status = p_status, used_wo_id = p_wo, note = coalesce(note,'') || ' | ' || coalesce(p_note,'')
   where id = p_id and status = 'available';
  if not found then raise exception 'Sisa bahan tidak tersedia.'; end if;
end $$;

create or replace function public.wo_finish(p_id uuid) returns void
language plpgsql security definer set search_path = public as $$
declare w work_orders;
begin
  perform require_perm('production','edit');
  select * into w from work_orders where id = p_id for update;
  if w.status <> 'in_progress' then raise exception 'WO tidak sedang dikerjakan.'; end if;
  if exists(select 1 from bom_lines where product_id = w.product_id) and not exists(select 1 from wo_consumptions where wo_id = p_id) then
    raise exception 'Catat konsumsi bahan dulu sebelum menyelesaikan WO.';
  end if;
  update work_orders set status = 'qc', finished_at = now() where id = p_id;
end $$;

create or replace function public.wo_qc(p_id uuid, p_pass boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare w work_orders; v_labor numeric; v_unit numeric; v_prod products;
begin
  perform require_perm('production','approve');
  select * into w from work_orders where id = p_id for update;
  if w.status <> 'qc' then raise exception 'WO tidak sedang menunggu QC.'; end if;
  if w.assigned_to = _uid() then raise exception 'Pemisahan tugas: operator tidak boleh meng-QC hasil kerjanya sendiri.'; end if;
  if not p_pass then
    if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Jelaskan temuan QC.'; end if;
    update work_orders set status = 'in_progress', qc_by = _uid(), qc_at = now(), qc_note = p_note where id = p_id;
    return;
  end if;
  select * into v_prod from products where id = w.product_id;
  v_labor := round(v_prod.labor_cost * w.qty, 2);
  v_unit := round((w.material_cost + v_labor) / w.qty, 4);
  perform _apply_avg(w.product_id, w.qty, v_unit, w.no);
  perform _post_stock(w.product_id, w.location_id, w.qty, v_unit, 'WO', w.id, w.no, 'Hasil produksi lolos QC');
  update work_orders set status = 'done', qc_by = _uid(), qc_at = now(), qc_note = p_note, labor_cost = v_labor where id = p_id;
  perform _post_journal(today_jkt(), 'Hasil produksi ' || w.no, _branch_of_loc(w.location_id), 'WO', w.id, jsonb_build_array(
    jsonb_build_object('a','1301','d', w.material_cost + v_labor),
    jsonb_build_object('a','1302','c', w.material_cost),
    jsonb_build_object('a','5105','c', v_labor)));
  if w.so_line_id is not null then
    perform _reserve(w.product_id, w.location_id, w.qty, true);
    update so_lines set reserved_qty = reserved_qty + w.qty where id = w.so_line_id;
    if not exists(select 1 from work_orders where so_id = w.so_id and status not in ('done','cancelled')) then
      update sales_orders set status = 'ready', updated_at = now() where id = w.so_id and status = 'in_production';
    end if;
  end if;
end $$;

-- =====================================================================
--  RPC: PENGIRIMAN
-- =====================================================================
create or replace function public.do_create(p_so uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare s sales_orders; v_id uuid;
begin
  perform require_perm('logistics','create');
  select * into s from sales_orders where id = p_so for update;
  perform require_branch(s.branch_id);
  if s.status <> 'ready' then raise exception 'Pesanan belum siap kirim (status: %).', s.status; end if;
  if exists(select 1 from delivery_orders where so_id = p_so) then raise exception 'Surat jalan untuk pesanan ini sudah dibuat.'; end if;
  insert into delivery_orders(no, so_id, location_id, created_by) values (next_no('DO'), p_so, s.location_id, _uid()) returning id into v_id;
  return v_id;
end $$;

create or replace function public.do_pack(p_id uuid, p_photo text, p_scan jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare d delivery_orders; s sales_orders; r record; v_scanned numeric; v_serials text[]; sr text; v_bad text := '';
begin
  perform require_perm('logistics','edit');
  select * into d from delivery_orders where id = p_id for update;
  if d.status <> 'packing' then raise exception 'Surat jalan tidak dalam tahap packing.'; end if;
  if coalesce(p_photo,'') = '' then raise exception 'Foto isi paket wajib diambil sebelum dus ditutup.'; end if;
  select * into s from sales_orders where id = d.so_id;
  for r in select l.product_id, sum(l.qty) qty, bool_or(p.track_serial) track, max(p.sku) sku
             from so_lines l join products p on p.id = l.product_id where l.so_id = d.so_id and p.is_stock group by l.product_id loop
    select coalesce(sum((x->>'qty')::numeric),0) into v_scanned from jsonb_array_elements(coalesce(p_scan,'[]')) x
     where (x->>'product_id')::uuid = r.product_id;
    if v_scanned <> r.qty then v_bad := v_bad || format('%s: pesanan %s, discan %s; ', r.sku, r.qty, v_scanned); end if;
    if r.track then
      select array_agg(distinct s2) into v_serials from jsonb_array_elements(coalesce(p_scan,'[]')) x,
        jsonb_array_elements_text(coalesce(x->'serials','[]')) s2 where (x->>'product_id')::uuid = r.product_id;
      if coalesce(array_length(v_serials,1),0) <> r.qty then v_bad := v_bad || format('%s wajib scan %s serial; ', r.sku, r.qty);
      else
        foreach sr in array v_serials loop
          if not exists(select 1 from serial_units where serial = sr and product_id = r.product_id and status = 'in_stock' and location_id = d.location_id) then
            v_bad := v_bad || format('serial %s tidak tersedia; ', sr);
          end if;
        end loop;
        update so_lines set serials = v_serials where so_id = d.so_id and product_id = r.product_id;
      end if;
    end if;
  end loop;
  if v_bad <> '' then raise exception 'Isi paket tidak cocok dengan pesanan: %', v_bad; end if;
  update delivery_orders set status = 'packed', packed_by = _uid(), packed_at = now(), packing_photo_path = p_photo, scan_log = p_scan where id = p_id;
end $$;

create or replace function public.do_ship(p_id uuid, p_courier text, p_tracking text, p_cost numeric) returns void
language plpgsql security definer set search_path = public as $$
declare d delivery_orders; s sales_orders; l so_lines; v_prod products; v_cost numeric; sr text;
begin
  perform require_perm('logistics','edit');
  select * into d from delivery_orders where id = p_id for update;
  if d.status <> 'packed' then raise exception 'Paket belum diverifikasi & difoto.'; end if;
  if coalesce(trim(p_courier),'') = '' then raise exception 'Ekspedisi/kurir wajib diisi.'; end if;
  if coalesce(trim(p_tracking),'') = '' and p_courier not in ('Ambil Sendiri','Kurir Toko') then
    raise exception 'Nomor resi wajib diisi.';
  end if;
  select * into s from sales_orders where id = d.so_id for update;
  for l in select * from so_lines where so_id = s.id loop
    select * into v_prod from products where id = l.product_id;
    if not v_prod.is_stock then continue; end if;
    if l.serials is not null and array_length(l.serials,1) > 0 and v_prod.track_serial then
      foreach sr in array l.serials loop
        v_cost := _post_stock(l.product_id, d.location_id, -1, null, 'DO', d.id, d.no, 'Kirim ' || s.no, 1, false, sr);
        update serial_units set status = 'sold', last_doc_no = d.no, updated_at = now() where serial = sr;
      end loop;
    else
      v_cost := _post_stock(l.product_id, d.location_id, -l.qty, null, 'DO', d.id, d.no, 'Kirim ' || s.no, l.reserved_qty);
    end if;
    update so_lines set unit_cost = v_cost, reserved_qty = 0 where id = l.id;
  end loop;
  update delivery_orders set status = 'shipped', courier = p_courier, tracking_no = nullif(trim(p_tracking),''),
    shipping_cost = coalesce(p_cost,0), shipped_by = _uid(), shipped_at = now() where id = p_id;
  update sales_orders set status = 'shipped', updated_at = now() where id = s.id;
  perform _recognize_so(s.id);
end $$;

create or replace function public.do_deliver(p_id uuid, p_proof text) returns void
language plpgsql security definer set search_path = public as $$
declare d delivery_orders;
begin
  perform require_perm('logistics','edit');
  select * into d from delivery_orders where id = p_id for update;
  if d.status <> 'shipped' then raise exception 'Paket belum dikirim.'; end if;
  update delivery_orders set status = 'delivered', delivered_at = now(), delivered_by = _uid(), proof_path = p_proof where id = p_id;
  update sales_orders set status = 'completed', updated_at = now() where id = d.so_id;
end $$;

create or replace function public.claim_create(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare d delivery_orders; v_id uuid;
begin
  perform require_perm('claims','create');
  select * into d from delivery_orders where id = (p->>'do_id')::uuid;
  if d.status not in ('shipped','delivered') then raise exception 'Klaim hanya untuk paket yang sudah dikirim.'; end if;
  if length(trim(coalesce(p->>'reason',''))) < 10 then raise exception 'Jelaskan kejadian (min. 10 karakter).'; end if;
  insert into courier_claims(no, do_id, courier, reason, claim_amount, note, created_by)
  values (next_no('KLM'), d.id, d.courier, p->>'reason', (p->>'claim_amount')::numeric, p->>'note', _uid()) returning id into v_id;
  return v_id;
end $$;

create or replace function public.claim_update(p_id uuid, p_status text, p_received numeric, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare c courier_claims;
begin
  perform require_perm('claims','edit');
  select * into c from courier_claims where id = p_id for update;
  if c.status in ('paid','rejected') then raise exception 'Klaim sudah ditutup.'; end if;
  if p_status = 'paid' and coalesce(p_received,0) <= 0 then raise exception 'Isi nominal yang diterima dari ekspedisi.'; end if;
  update courier_claims set status = p_status, received_amount = coalesce(p_received, received_amount),
    note = coalesce(p_note, note), updated_by = _uid(), updated_at = now() where id = p_id;
  if p_status = 'paid' then
    perform _post_journal(today_jkt(), 'Penggantian klaim ' || c.no, null, 'KLM', c.id, jsonb_build_array(
      jsonb_build_object('a','1102','d',p_received), jsonb_build_object('a','6205','c',p_received)));
  end if;
end $$;

-- =====================================================================
--  RPC: RETUR
-- =====================================================================
create or replace function public.return_create(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare s sales_orders; v_id uuid; l jsonb; v_sold numeric; v_ret numeric; v_cost numeric;
begin
  perform require_perm('returns','create');
  select * into s from sales_orders where id = (p->>'so_id')::uuid;
  if not found then raise exception 'Pesanan tidak ditemukan.'; end if;
  perform require_branch(s.branch_id);
  if s.status not in ('shipped','completed') then raise exception 'Retur hanya untuk pesanan yang barangnya sudah diserahkan.'; end if;
  if not exists(select 1 from return_reasons where code = p->>'reason_code') then raise exception 'Penyebab retur wajib dipilih.'; end if;
  if coalesce((p->>'refund_amount')::numeric,0) > s.total then raise exception 'Nilai refund melebihi total pesanan.'; end if;
  insert into sales_returns(no, so_id, channel_id, branch_id, location_id, return_tracking_no, courier, reason_code, reason_note, refund_amount, created_by)
  values (next_no('RTR'), s.id, s.channel_id, s.branch_id, _loc_of_kind(s.branch_id, 'quarantine'), nullif(p->>'tracking_no',''), p->>'courier',
          p->>'reason_code', p->>'reason_note', coalesce(nullif(p->>'refund_amount','')::numeric,0), _uid())
  returning id into v_id;
  for l in select * from jsonb_array_elements(p->'lines') loop
    select coalesce(sum(qty),0), max(unit_cost) into v_sold, v_cost from so_lines where so_id = s.id and product_id = (l->>'product_id')::uuid;
    select coalesce(sum(rl.qty_expected),0) into v_ret from return_lines rl join sales_returns r on r.id = rl.return_id
     where r.so_id = s.id and rl.product_id = (l->>'product_id')::uuid and r.status <> 'cancelled' and r.id <> v_id;
    if (l->>'qty')::numeric > v_sold - v_ret then raise exception 'Jumlah retur melebihi jumlah terjual (sisa %).', v_sold - v_ret; end if;
    insert into return_lines(return_id, product_id, qty_expected, unit_cost) values (v_id, (l->>'product_id')::uuid, (l->>'qty')::numeric, coalesce(v_cost,0));
  end loop;
  if not exists(select 1 from return_lines where return_id = v_id) then raise exception 'Pilih barang yang diretur.'; end if;
  return v_id;
end $$;

create or replace function public.return_receive(p_id uuid, p_lines jsonb, p_photo text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare r sales_returns; rl return_lines; v_qty numeric; v_val numeric := 0; e jsonb;
begin
  perform require_perm('return_receive','create');
  select * into r from sales_returns where id = p_id for update;
  if r.status <> 'expected' then raise exception 'Retur ini sudah diterima/ditutup.'; end if;
  perform require_branch(r.branch_id);
  if r.created_by = _uid() then raise exception 'Pemisahan tugas: pemroses retur tidak boleh menerima barang returnya sendiri.'; end if;
  if coalesce(p_photo,'') = '' then raise exception 'Foto saat membuka paket retur wajib diunggah.'; end if;
  for rl in select * from return_lines where return_id = p_id loop
    select (x->>'qty_received')::numeric, x into v_qty, e from jsonb_array_elements(p_lines) x where (x->>'line_id')::uuid = rl.id;
    if v_qty is null then raise exception 'Isi jumlah diterima untuk semua barang (0 jika tidak ada).'; end if;
    if v_qty < 0 or v_qty > rl.qty_expected then raise exception 'Jumlah diterima tidak valid.'; end if;
    if v_qty > 0 then
      perform _post_stock(rl.product_id, r.location_id, v_qty, rl.unit_cost, 'RTR', r.id, r.no, 'Barang retur masuk karantina');
    end if;
    update return_lines set qty_received = v_qty, condition = e->>'condition' where id = rl.id;
    v_val := v_val + round(v_qty * rl.unit_cost, 2);
  end loop;
  update sales_returns set status = 'received', received_by = _uid(), received_at = now(), unboxing_photo_path = p_photo,
    receive_note = p_note, cost_value = v_val where id = p_id;
  update sales_orders set refund_total = refund_total + r.refund_amount, updated_at = now() where id = r.so_id;
  perform _post_journal(today_jkt(), 'Retur ' || r.no, r.branch_id, 'RTR', r.id, jsonb_build_array(
    jsonb_build_object('a','1301','d',v_val), jsonb_build_object('a','5101','c',v_val),
    jsonb_build_object('a','4104','d',r.refund_amount), jsonb_build_object('a','1201','c',r.refund_amount)));
end $$;

create or replace function public.return_cancel(p_id uuid, p_reason text) returns void
language plpgsql security definer set search_path = public as $$
begin
  perform require_perm('returns','approve');
  if length(trim(coalesce(p_reason,''))) < 10 then raise exception 'Alasan pembatalan retur wajib dijelaskan.'; end if;
  update sales_returns set status = 'cancelled', receive_note = p_reason, received_by = _uid(), received_at = now()
   where id = p_id and status = 'expected';
  if not found then raise exception 'Retur tidak dalam status menunggu barang.'; end if;
end $$;

create or replace function public.return_dispose(p_id uuid, p_disp text, p_charge_to text, p_party text, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare r sales_returns; rl return_lines; v_main uuid; v_scrap uuid; v_val numeric := 0;
begin
  perform require_perm('returns','approve');
  select * into r from sales_returns where id = p_id for update;
  if r.status <> 'received' then raise exception 'Disposisi hanya untuk barang retur yang sudah diterima QC.'; end if;
  if p_disp not in ('rework','markdown','writeoff') then raise exception 'Pilih disposisi.'; end if;
  if p_charge_to is null then raise exception 'Pilih pihak yang menanggung biaya retur.'; end if;
  if p_charge_to in ('operator','branch','courier','warehouse') and length(trim(coalesce(p_party,''))) < 3 then
    raise exception 'Sebutkan nama penanggung jawab.';
  end if;
  v_main := _loc_of_kind(r.branch_id, 'main'); v_scrap := _loc_of_kind(r.branch_id, 'scrap');
  for rl in select * from return_lines where return_id = p_id and coalesce(qty_received,0) > 0 loop
    perform _post_stock(rl.product_id, r.location_id, -rl.qty_received, rl.unit_cost, 'RTR-D', r.id, r.no, 'Disposisi: ' || p_disp);
    perform _post_stock(rl.product_id, case when p_disp = 'writeoff' then v_scrap else v_main end, rl.qty_received, rl.unit_cost,
                        'RTR-D', r.id, r.no, 'Disposisi: ' || p_disp);
    v_val := v_val + round(rl.qty_received * rl.unit_cost, 2);
  end loop;
  update sales_returns set status = 'dispositioned', disposition = p_disp, charge_to = p_charge_to, charge_party = p_party,
    disposed_by = _uid(), disposed_at = now(), dispose_note = p_note where id = p_id;
  if p_disp = 'writeoff' then
    perform _post_journal(today_jkt(), 'Write-off retur ' || r.no, r.branch_id, 'RTR-D', r.id, jsonb_build_array(
      jsonb_build_object('a','5104','d',v_val), jsonb_build_object('a','1301','c',v_val)));
  end if;
end $$;
-- =====================================================================
--  RPC: KEUANGAN
-- =====================================================================
create or replace function public.payment_create(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare s sales_orders; v_pending numeric; v_amt numeric := (p->>'amount')::numeric; v_sess uuid;
begin
  perform require_perm('payments','create');
  select * into s from sales_orders where id = (p->>'so_id')::uuid for update;
  if not found then raise exception 'Pesanan tidak ditemukan.'; end if;
  perform require_branch(s.branch_id);
  if s.status in ('void','cancelled','quotation') then raise exception 'Pesanan ini tidak bisa menerima pembayaran.'; end if;
  select coalesce(sum(amount),0) into v_pending from payments where so_id = s.id and status = 'pending';
  if v_amt > _outstanding(s) - v_pending + 0.5 then
    raise exception 'Nominal melebihi sisa tagihan (sisa Rp %, menunggu verifikasi Rp %).', _outstanding(s), v_pending;
  end if;
  if p->>'method' = 'cash' then v_sess := _open_session(s.branch_id); end if;
  return _insert_payment(s, p, v_sess);
end $$;

create or replace function public.payment_verify(p_id uuid, p_approve boolean, p_note text, p_bank_tx uuid default null) returns void
language plpgsql security definer set search_path = public as $$
declare py payments; s sales_orders; bt bank_transactions;
begin
  perform require_perm('payments','approve');
  select * into py from payments where id = p_id for update;
  if py.status <> 'pending' then raise exception 'Pembayaran ini sudah diproses.'; end if;
  select * into s from sales_orders where id = py.so_id for update;
  if _uid() in (py.created_by, s.created_by) then
    raise exception 'Pemisahan tugas: penginput pesanan/pembayaran tidak boleh memverifikasi pembayarannya sendiri.';
  end if;
  if not p_approve then
    if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Alasan penolakan wajib diisi.'; end if;
    update payments set status = 'rejected', verified_by = _uid(), verified_at = now(), verify_note = p_note where id = p_id;
    return;
  end if;
  if p_bank_tx is not null then
    select * into bt from bank_transactions where id = p_bank_tx for update;
    if bt.matched_payment_id is not null then raise exception 'Mutasi bank ini sudah dicocokkan ke pembayaran lain.'; end if;
    if bt.amount <> py.amount or bt.bank_account_id <> py.bank_account_id then
      raise exception 'Mutasi bank tidak cocok (nominal/rekening berbeda).';
    end if;
    update bank_transactions set matched_payment_id = p_id, matched_by = _uid(), matched_at = now() where id = p_bank_tx;
  end if;
  update payments set status = 'verified', verified_by = _uid(), verified_at = now(), verify_note = p_note, bank_tx_id = p_bank_tx where id = p_id;
  update sales_orders set paid_verified = paid_verified + py.amount, updated_at = now() where id = s.id;
  perform _post_journal(today_jkt(), 'Verifikasi ' || py.no || ' / ' || s.no, s.branch_id, 'PAY', py.id, jsonb_build_array(
    jsonb_build_object('a','1102','d',py.amount),
    jsonb_build_object('a', case when s.recognized_at is null then '2201' else '1201' end, 'c', py.amount)));
end $$;

-- ---------- kas cabang ----------
create or replace function public.cash_open(p_branch uuid, p_opening numeric) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  perform require_perm('cash','create');
  perform require_branch(p_branch);
  if _open_session(p_branch) is not null then raise exception 'Anda masih punya sesi kas terbuka di cabang ini.'; end if;
  insert into cash_sessions(no, branch_id, opened_by, opening_cash) values (next_no('KAS'), p_branch, _uid(), coalesce(p_opening,0))
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.cash_expected(p_id uuid) returns numeric
language sql stable security definer set search_path = public as $$
  select c.opening_cash
       + coalesce((select sum(amount) from payments where cash_session_id = c.id and method = 'cash' and status = 'verified'), 0)
       - coalesce((select sum(amount) from expenses where cash_session_id = c.id and status <> 'rejected'), 0)
    from cash_sessions c where c.id = p_id
$$;

create or replace function public.cash_close(p_id uuid, p_counted numeric, p_reason text) returns text
language plpgsql security definer set search_path = public as $$
declare c cash_sessions; v_exp numeric; v_diff numeric;
begin
  perform require_perm('cash','create');
  select * into c from cash_sessions where id = p_id for update;
  if c.status <> 'open' then raise exception 'Sesi kas sudah ditutup.'; end if;
  if c.opened_by <> _uid() then raise exception 'Hanya kasir pembuka sesi yang boleh menutup kas.'; end if;
  if exists(select 1 from sales_orders where branch_id = c.branch_id and kind = 'pos' and status = 'draft' and created_by = _uid()
            and discount_status in ('pending','approved')) then
    raise exception 'Masih ada transaksi kasir tertahan. Selesaikan atau batalkan dulu.';
  end if;
  v_exp := cash_expected(p_id);
  v_diff := round(coalesce(p_counted,0) - v_exp, 2);
  if v_diff <> 0 and length(trim(coalesce(p_reason,''))) < 10 then
    raise exception 'Ada selisih kas Rp %. Jelaskan penyebabnya (min. 10 karakter).', v_diff;
  end if;
  update cash_sessions set status = case when v_diff = 0 then 'approved' else 'closed' end, closed_at = now(),
    expected_cash = v_exp, counted_cash = p_counted, diff = v_diff, diff_reason = p_reason,
    decide_note = case when v_diff = 0 then 'Otomatis: tidak ada selisih' end where id = p_id;
  return case when v_diff = 0 then 'approved' else 'closed' end;
end $$;

create or replace function public.cash_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare c cash_sessions;
begin
  perform require_perm('cash','approve');
  select * into c from cash_sessions where id = p_id for update;
  if c.status not in ('closed','rejected') then raise exception 'Sesi kas tidak menunggu approval selisih.'; end if;
  if c.opened_by = _uid() then raise exception 'Pemisahan tugas: kasir tidak boleh menyetujui selisih kasnya sendiri.'; end if;
  if length(trim(coalesce(p_note,''))) < 5 then raise exception 'Catatan keputusan wajib diisi.'; end if;
  update cash_sessions set status = case when p_approve then 'approved' else 'rejected' end,
    decided_by = _uid(), decided_at = now(), decide_note = p_note where id = p_id;
  if p_approve then
    perform _post_journal(today_jkt(), 'Selisih kas ' || c.no, c.branch_id, 'KAS', c.id, jsonb_build_array(
      jsonb_build_object('a','1101','d',c.diff), jsonb_build_object('a','6203','c',c.diff)));
  end if;
end $$;

create or replace function public.cash_deposit(p_id uuid, p_amount numeric, p_bank uuid, p_proof text) returns void
language plpgsql security definer set search_path = public as $$
declare c cash_sessions;
begin
  perform require_perm('cash','create');
  select * into c from cash_sessions where id = p_id for update;
  perform require_branch(c.branch_id);
  if c.status = 'open' then raise exception 'Tutup kas dulu sebelum setor.'; end if;
  if c.deposit_status in ('pending','verified') then raise exception 'Setoran sesi ini sudah dicatat.'; end if;
  if coalesce(p_amount,0) <= 0 then raise exception 'Nominal setoran harus lebih dari 0.'; end if;
  if coalesce(p_proof,'') = '' then raise exception 'Bukti setoran wajib diunggah.'; end if;
  if not exists(select 1 from bank_accounts where id = p_bank and active) then raise exception 'Pilih rekening perusahaan terdaftar.'; end if;
  update cash_sessions set deposit_amount = p_amount, deposit_bank_id = p_bank, deposit_proof_path = p_proof,
    deposit_status = 'pending', deposit_by = _uid(), deposit_at = now() where id = p_id;
end $$;

create or replace function public.cash_deposit_verify(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare c cash_sessions;
begin
  perform require_perm('payments','approve');
  select * into c from cash_sessions where id = p_id for update;
  if c.deposit_status <> 'pending' then raise exception 'Tidak ada setoran yang menunggu verifikasi.'; end if;
  if _uid() in (c.deposit_by, c.opened_by) then raise exception 'Pemisahan tugas: penyetor tidak boleh memverifikasi setorannya.'; end if;
  update cash_sessions set deposit_status = case when p_approve then 'verified' else 'rejected' end,
    deposit_verified_by = _uid(), deposit_verified_at = now(), decide_note = coalesce(decide_note,'') || ' | Setoran: ' || coalesce(p_note,'')
   where id = p_id;
  if p_approve then
    perform _post_journal(today_jkt(), 'Setoran kas ' || c.no, c.branch_id, 'SETOR', c.id, jsonb_build_array(
      jsonb_build_object('a','1102','d',c.deposit_amount), jsonb_build_object('a','1101','c',c.deposit_amount)));
  end if;
end $$;

-- ---------- biaya operasional ----------
create or replace function public.expense_create(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_branch uuid := (p->>'branch_id')::uuid; v_sess uuid; v_id uuid;
begin
  perform require_perm('expenses','create');
  perform require_branch(v_branch);
  if coalesce(p->>'proof_path','') = '' then raise exception 'Bukti/nota biaya wajib diunggah.'; end if;
  if length(trim(coalesce(p->>'description',''))) < (case when p->>'category' = 'lainnya' then 10 else 3 end) then
    raise exception 'Keterangan biaya wajib diisi%.', case when p->>'category' = 'lainnya' then ' dengan jelas (min. 10 karakter)' else '' end;
  end if;
  if p->>'pay_method' = 'cash' then
    v_sess := _open_session(v_branch);
    if v_sess is null then raise exception 'Biaya tunai diambil dari sesi kas yang sedang dibuka. Buka kas dulu.'; end if;
  elsif not exists(select 1 from bank_accounts where id = nullif(p->>'bank_account_id','')::uuid and active) then
    raise exception 'Pilih rekening perusahaan.';
  end if;
  insert into expenses(no, branch_id, exp_date, category, amount, description, pay_method, bank_account_id, cash_session_id, proof_path, created_by)
  values (next_no('BYA'), v_branch, coalesce(nullif(p->>'exp_date','')::date, today_jkt()), p->>'category', (p->>'amount')::numeric,
          p->>'description', p->>'pay_method', nullif(p->>'bank_account_id','')::uuid, v_sess, p->>'proof_path', _uid())
  returning id into v_id;
  return v_id;
end $$;

create or replace function public.expense_decide(p_id uuid, p_approve boolean, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare e expenses; v_acc text;
begin
  perform require_perm('expenses','approve');
  select * into e from expenses where id = p_id for update;
  if e.status <> 'pending' then raise exception 'Biaya sudah diputuskan.'; end if;
  if e.created_by = _uid() then raise exception 'Pemisahan tugas: penginput biaya tidak boleh menyetujui sendiri.'; end if;
  if not p_approve and length(trim(coalesce(p_note,''))) < 5 then raise exception 'Alasan penolakan wajib diisi.'; end if;
  update expenses set status = case when p_approve then 'approved' else 'rejected' end, decided_by = _uid(), decided_at = now(), decide_note = p_note
   where id = p_id;
  if p_approve then
    select account_code into v_acc from expense_categories where code = e.category;
    perform _post_journal(e.exp_date, 'Biaya ' || e.no || ': ' || e.description, e.branch_id, 'BYA', e.id, jsonb_build_array(
      jsonb_build_object('a',v_acc,'d',e.amount), jsonb_build_object('a', case when e.pay_method = 'cash' then '1101' else '1102' end, 'c', e.amount)));
  end if;
end $$;

-- ---------- rekonsiliasi bank ----------
create or replace function public.bank_import(p_bank uuid, p_rows jsonb) returns jsonb
language plpgsql security definer set search_path = public as $$
declare v_n int;
begin
  perform require_perm('bank_recon','create');
  with ins as (
    insert into bank_transactions(bank_account_id, tx_date, description, amount, ref, imported_by)
    select p_bank, (r->>'date')::date, coalesce(r->>'description',''), (r->>'amount')::numeric, r->>'ref', _uid()
      from jsonb_array_elements(p_rows) r where nullif(r->>'amount','') is not null
    on conflict do nothing returning 1)
  select count(*) into v_n from ins;
  return jsonb_build_object('inserted', v_n, 'total', jsonb_array_length(p_rows));
end $$;

create or replace function public.bank_match(p_tx uuid, p_payment uuid, p_note text) returns void
language plpgsql security definer set search_path = public as $$
declare bt bank_transactions;
begin
  perform require_perm('bank_recon','edit');
  select * into bt from bank_transactions where id = p_tx for update;
  if bt.matched_payment_id is not null or bt.matched_note is not null then raise exception 'Mutasi ini sudah dicocokkan.'; end if;
  if p_payment is null and length(trim(coalesce(p_note,''))) < 5 then
    raise exception 'Tanpa pembayaran terkait, jelaskan mutasi ini (mis. setoran kas, settlement, bayar supplier).';
  end if;
  if p_payment is not null then
    if exists(select 1 from bank_transactions where matched_payment_id = p_payment) then raise exception 'Pembayaran sudah punya pasangan mutasi.'; end if;
    update payments set bank_tx_id = p_tx where id = p_payment;
  end if;
  update bank_transactions set matched_payment_id = p_payment, matched_note = p_note, matched_by = _uid(), matched_at = now() where id = p_tx;
end $$;

-- ---------- settlement marketplace ----------
create or replace function public.settlement_preview(p_channel uuid, p_from date, p_to date) returns jsonb
language sql stable security definer set search_path = public as $$
  select jsonb_build_object('orders', count(*), 'gross', coalesce(sum(total),0), 'fees', coalesce(sum(channel_fee),0),
     'vouchers', coalesce(sum(voucher_seller),0), 'refunds', coalesce(sum(refund_total),0),
     'paid', coalesce(sum(paid_verified),0), 'expected_net', coalesce(sum(_outstanding(s)),0))
  from sales_orders s
  where s.channel_id = p_channel and s.recognized_at is not null and s.status not in ('void','cancelled')
    and (s.recognized_at at time zone 'Asia/Jakarta')::date between p_from and p_to and _outstanding(s) > 0.005
$$;

create or replace function public.settlement_record(p jsonb) returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid; v_prev jsonb; s sales_orders; v_amt numeric := (p->>'received_amount')::numeric; v_no text;
begin
  perform require_perm('settlement','create');
  if not exists(select 1 from bank_accounts where id = nullif(p->>'bank_account_id','')::uuid and active) then
    raise exception 'Pilih rekening perusahaan penerima pencairan.';
  end if;
  v_prev := settlement_preview((p->>'channel_id')::uuid, (p->>'date_from')::date, (p->>'date_to')::date);
  if (v_prev->>'orders')::int = 0 then raise exception 'Tidak ada pesanan terbuka pada periode ini.'; end if;
  v_no := next_no('STL');
  insert into channel_settlements(no, channel_id, period_from, period_to, orders_count, gross, fees, vouchers, refunds, expected_net,
     received_amount, diff, bank_account_id, proof_path, note, created_by)
  values (v_no, (p->>'channel_id')::uuid, (p->>'date_from')::date, (p->>'date_to')::date, (v_prev->>'orders')::int,
     (v_prev->>'gross')::numeric, (v_prev->>'fees')::numeric, (v_prev->>'vouchers')::numeric, (v_prev->>'refunds')::numeric,
     (v_prev->>'expected_net')::numeric, v_amt, v_amt - (v_prev->>'expected_net')::numeric,
     (p->>'bank_account_id')::uuid, p->>'proof_path', p->>'note', _uid())
  returning id into v_id;
  if abs(v_amt - (v_prev->>'expected_net')::numeric) > 0 and length(trim(coalesce(p->>'note',''))) < 10 then
    raise exception 'Ada selisih Rp %. Jelaskan penyebabnya di catatan.', v_amt - (v_prev->>'expected_net')::numeric;
  end if;
  for s in select * from sales_orders x where x.channel_id = (p->>'channel_id')::uuid and x.recognized_at is not null
             and x.status not in ('void','cancelled')
             and (x.recognized_at at time zone 'Asia/Jakarta')::date between (p->>'date_from')::date and (p->>'date_to')::date
             and _outstanding(x) > 0.005 for update loop
    insert into payments(no, so_id, branch_id, amount, method, bank_account_id, status, settlement_id, created_by, verified_by, verified_at, verify_note)
    values (next_no('PAY'), s.id, s.branch_id, _outstanding(s), 'marketplace', (p->>'bank_account_id')::uuid, 'verified', v_id, _uid(), _uid(), now(), 'Settlement ' || v_no);
    update sales_orders set paid_verified = paid_verified + _outstanding(s) where id = s.id;
  end loop;
  perform _post_journal(today_jkt(), 'Settlement ' || v_no, null, 'STL', v_id, jsonb_build_array(
    jsonb_build_object('a','1102','d',v_amt),
    jsonb_build_object('a','6204','d',(v_prev->>'expected_net')::numeric - v_amt),
    jsonb_build_object('a','1201','c',(v_prev->>'expected_net')::numeric)));
  return v_id;
end $$;

-- =====================================================================
--  RPC: PENGGUNA & PROFIL
-- =====================================================================
create or replace function public.me() returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_out jsonb;
begin
  if auth.uid() is null then return null; end if;
  select jsonb_build_object(
    'id', p.id, 'email', p.email, 'full_name', p.full_name, 'active', p.active,
    'roles', coalesce((select jsonb_agg(jsonb_build_object('code', r.code, 'name', r.name) order by r.sort)
                         from user_roles ur join roles r on r.code = ur.role where ur.user_id = p.id), '[]'),
    'is_global', is_global(), 'is_owner', has_role('owner'),
    'branches', coalesce((select jsonb_agg(jsonb_build_object('id', b.id, 'code', b.code, 'name', b.name, 'kind', b.kind) order by b.code)
                            from branches b where b.active and (is_global() or exists(select 1 from user_branches ub where ub.user_id = p.id and ub.branch_id = b.id))), '[]'),
    'perms', coalesce((select jsonb_object_agg(z.module, jsonb_build_object('v', z.pv, 'c', z.pc, 'e', z.pe, 'a', z.pa)) from (
                select module, bool_or(can_view or can_create or can_edit or can_approve) pv, bool_or(can_create) pc,
                       bool_or(can_edit) pe, bool_or(can_approve) pa
                  from role_permissions where role = any(my_roles()) group by module) z), '{}'),
    'discount_limit', my_discount_limit(),
    'settings', (select jsonb_object_agg(key, value) from app_settings)
  ) into v_out from profiles p where p.id = auth.uid();
  return v_out;
end $$;

create or replace function public.user_admin(p jsonb) returns void
language plpgsql security definer set search_path = public as $$
declare v_user uuid := (p->>'user_id')::uuid; v_roles text[]; v_br uuid[];
begin
  perform require_perm('users','edit');
  select coalesce(array_agg(x), '{}') into v_roles from jsonb_array_elements_text(coalesce(p->'roles','[]')) x;
  select coalesce(array_agg(x::uuid), '{}') into v_br from jsonb_array_elements_text(coalesce(p->'branches','[]')) x;
  if not has_role('owner') and ('owner' = any(v_roles) or exists(select 1 from user_roles where user_id = v_user and role = 'owner')) then
    raise exception 'Hanya Owner yang boleh mengatur jabatan Owner.';
  end if;
  if v_user = auth.uid() and not has_role('owner') then raise exception 'Anda tidak boleh mengubah jabatan sendiri.'; end if;
  update profiles set full_name = coalesce(nullif(trim(p->>'full_name'),''), full_name), phone = p->>'phone',
    active = coalesce((p->>'active')::boolean, active) where id = v_user;
  delete from user_roles where user_id = v_user and not (role = any(v_roles));
  insert into user_roles(user_id, role) select v_user, r from unnest(v_roles) r
   where not exists(select 1 from user_roles where user_id = v_user and role = r);
  delete from user_branches where user_id = v_user and not (branch_id = any(v_br));
  insert into user_branches(user_id, branch_id) select v_user, b from unnest(v_br) b on conflict do nothing;
end $$;

create or replace function public.recalc_costs() returns int
language plpgsql security definer set search_path = public as $$
begin
  perform require_perm('bom','edit');
  return recalc_bom_costs();
end $$;
-- =====================================================================
--  LAPORAN: view (mengikuti RLS pemakai) & RPC dashboard
-- =====================================================================
create or replace view public.v_stock with (security_invoker = true) as
select b.product_id, b.location_id, l.branch_id, l.kind as loc_kind, l.name as location_name, br.name as branch_name,
       p.sku, p.name, p.category, p.uom, p.min_stock, p.avg_cost, p.track_serial,
       b.qty, b.reserved,
       coalesce((select sum(a.qty) from channel_allocations a where a.product_id = b.product_id and a.location_id = b.location_id), 0) as allocated,
       b.qty - b.reserved as available,
       round(b.qty * p.avg_cost, 2) as value, b.updated_at
  from stock_balances b
  join products p on p.id = b.product_id
  join stock_locations l on l.id = b.location_id
  left join branches br on br.id = l.branch_id;

create or replace view public.v_ledger with (security_invoker = true) as
select sl.id, sl.at, sl.product_id, p.sku, p.name, sl.location_id, l.name as location_name, l.branch_id,
       sl.qty, sl.unit_cost, sl.value, sl.doc_type, sl.doc_id, sl.doc_no, sl.note, sl.serial, sl.user_id, pr.full_name as user_name
  from stock_ledger sl
  join products p on p.id = sl.product_id
  join stock_locations l on l.id = sl.location_id
  left join profiles pr on pr.id = sl.user_id;

create or replace view public.v_ar with (security_invoker = true) as
select s.id, s.no, s.branch_id, b.name as branch_name, s.customer_id, s.customer_name, s.customer_phone,
       s.channel_id, c.name as channel_name, c.kind as channel_kind, s.created_by, pr.full_name as sales_name,
       s.total, s.paid_verified, s.channel_fee + s.voucher_seller + s.refund_total as deductions,
       public._outstanding(s) as outstanding, s.recognized_at::date as invoice_date, s.due_date,
       greatest(public.today_jkt() - s.due_date, 0) as days_overdue,
       case when public.today_jkt() - s.recognized_at::date <= 30 then '0-30'
            when public.today_jkt() - s.recognized_at::date <= 60 then '31-60'
            when public.today_jkt() - s.recognized_at::date <= 90 then '61-90' else '>90' end as bucket
  from sales_orders s
  join branches b on b.id = s.branch_id
  join sales_channels c on c.id = s.channel_id
  left join profiles pr on pr.id = s.created_by
 where s.recognized_at is not null and s.status not in ('void','cancelled') and public._outstanding(s) > 0.005;

create or replace view public.v_so_margin with (security_invoker = true) as
select s.id, s.no, s.kind, s.status, s.branch_id, b.name as branch_name, s.channel_id, c.name as channel_name, c.kind as channel_kind,
       s.customer_name, s.created_by, s.recognized_at,
       s.gross_list, s.gross_list - (s.subtotal - s.discount_amount) as discount, s.shipping_charge, s.refund_total,
       s.subtotal - s.discount_amount + s.shipping_charge - s.refund_total as net_sales,
       s.channel_fee, s.voucher_seller, coalesce(d.shipping_cost, 0) as shipping_cost, s.cogs,
       coalesce(r.back_value, 0) as return_value, coalesce(r.writeoff_value, 0) as writeoff_value,
       coalesce(w.scrap, 0) as scrap_cost,
       (s.subtotal - s.discount_amount + s.shipping_charge - s.refund_total) - s.channel_fee - s.voucher_seller
         - coalesce(d.shipping_cost,0) - s.cogs + coalesce(r.back_value,0) - coalesce(r.writeoff_value,0) - coalesce(w.scrap,0) as profit
  from sales_orders s
  join branches b on b.id = s.branch_id
  join sales_channels c on c.id = s.channel_id
  left join (select so_id, sum(shipping_cost) shipping_cost from delivery_orders group by so_id) d on d.so_id = s.id
  left join (select so_id, sum(cost_value) back_value, sum(case when disposition = 'writeoff' then cost_value else 0 end) writeoff_value
               from sales_returns where status in ('received','dispositioned') group by so_id) r on r.so_id = s.id
  left join (select so_id, sum(scrap_cost) scrap from work_orders group by so_id) w on w.so_id = s.id
 where s.recognized_at is not null and s.status <> 'void';

create or replace view public.v_return_aging with (security_invoker = true) as
select r.id, r.no, r.so_id, s.no as so_no, r.branch_id, b.name as branch_name, c.name as channel_name,
       r.return_tracking_no, r.courier, r.reason_code, r.refund_amount, r.created_at, r.created_by, pr.full_name as created_name,
       (public.today_jkt() - (r.created_at at time zone 'Asia/Jakarta')::date) as days_waiting,
       (select sum(rl.qty_expected * rl.unit_cost) from return_lines rl where rl.return_id = r.id) as value_at_risk
  from sales_returns r
  join sales_orders s on s.id = r.so_id
  join branches b on b.id = r.branch_id
  join sales_channels c on c.id = r.channel_id
  left join profiles pr on pr.id = r.created_by
 where r.status = 'expected';

create or replace view public.v_return_recon with (security_invoker = true) as
select c.id as channel_id, c.name as channel_name, r.branch_id,
       count(distinct r.id) as returns,
       count(distinct r.id) filter (where r.status = 'expected') as waiting,
       coalesce(sum(rl.qty_expected),0) as qty_expected,
       coalesce(sum(rl.qty_received),0) as qty_received,
       coalesce(sum(case when r.status <> 'expected' then (rl.qty_expected - coalesce(rl.qty_received,0)) * rl.unit_cost end),0) as missing_value,
       (select coalesce(sum(r2.refund_amount),0) from sales_returns r2
         where r2.channel_id = c.id and r2.branch_id = r.branch_id and r2.status <> 'cancelled') as refund_total
  from sales_returns r
  join sales_channels c on c.id = r.channel_id
  left join return_lines rl on rl.return_id = r.id
 where r.status <> 'cancelled'
 group by c.id, c.name, r.branch_id;

create or replace view public.v_scrap with (security_invoker = true) as
select sc.id, sc.created_at, w.no as wo_no, w.id as wo_id, l.branch_id, p.sku, p.name as product_name, sc.qty, sc.cause, sc.note,
       sc.operator_id, op.full_name as operator_name, round(sc.qty * sc.unit_cost, 2) as value, sc.photo_path
  from wo_scraps sc
  join work_orders w on w.id = sc.wo_id
  join stock_locations l on l.id = w.location_id
  join products p on p.id = sc.product_id
  left join profiles op on op.id = sc.operator_id;

create or replace view public.v_cashier_audit with (security_invoker = true) as
select (s.created_at at time zone 'Asia/Jakarta')::date as day, s.branch_id, b.name as branch_name, s.created_by, pr.full_name as user_name,
       count(*) as transactions,
       count(*) filter (where s.void_status in ('pending','approved') and s.status in ('void','cancelled') or s.void_status = 'pending') as voids,
       coalesce(sum(s.gross_list - (s.subtotal - s.discount_amount)) filter (where s.status not in ('void','cancelled')),0) as discount_value,
       round(avg(s.discount_pct) filter (where s.status not in ('void','cancelled')), 2) as avg_discount_pct,
       count(*) filter (where s.discount_status in ('pending','approved','rejected')) as discount_approvals,
       coalesce(sum(s.total) filter (where s.status not in ('void','cancelled','draft','quotation')),0) as sales_value
  from sales_orders s
  join branches b on b.id = s.branch_id
  left join profiles pr on pr.id = s.created_by
 where s.kind in ('pos','order')
 group by 1, 2, 3, 4, 5;

create or replace view public.v_opname_diff with (security_invoker = true) as
select o.id as opname_id, o.no, o.kind, o.status, o.approved_at, date_trunc('month', coalesce(o.approved_at, o.submitted_at))::date as month,
       l.branch_id, l.name as location_name, p.sku, p.name as product_name, ol.system_qty, ol.counted_qty,
       ol.counted_qty - ol.system_qty as diff_qty, round((ol.counted_qty - ol.system_qty) * ol.unit_cost, 2) as diff_value,
       cb.full_name as counted_name, ab.full_name as approved_name
  from opname_lines ol
  join stock_opnames o on o.id = ol.opname_id
  join stock_locations l on l.id = o.location_id
  join products p on p.id = ol.product_id
  left join profiles cb on cb.id = o.counted_by
  left join profiles ab on ab.id = o.approved_by
 where o.status in ('submitted','approved') and ol.counted_qty is distinct from ol.system_qty;

create or replace view public.v_slow_moving with (security_invoker = true) as
select v.*, lo.last_out,
       coalesce(public.today_jkt() - (lo.last_out at time zone 'Asia/Jakarta')::date, 9999) as days_idle
  from public.v_stock v
  left join lateral (select max(sl.at) as last_out from stock_ledger sl
                      where sl.product_id = v.product_id and sl.location_id = v.location_id and sl.qty < 0
                        and sl.doc_type in ('POS','DO','WO','TRF')) lo on true
 where v.loc_kind = 'main' and v.qty > 0;

create or replace view public.v_price_history with (security_invoker = true) as
select gl.id, g.received_at, g.no as grn_no, po.no as po_no, s.name as supplier_name, po.supplier_id,
       p.id as product_id, p.sku, p.name as product_name, gl.qty, gl.unit_cost
  from gr_lines gl
  join goods_receipts g on g.id = gl.gr_id
  join purchase_orders po on po.id = g.po_id
  join suppliers s on s.id = po.supplier_id
  join products p on p.id = gl.product_id;

create or replace view public.v_wo_board with (security_invoker = true) as
select w.*, p.sku, p.name as product_name, s.no as so_no, s.customer_name, s.need_date, s.paid_verified, s.dp_required,
       l.branch_id, op.full_name as operator_name
  from work_orders w
  join products p on p.id = w.product_id
  join stock_locations l on l.id = w.location_id
  left join sales_orders s on s.id = w.so_id
  left join profiles op on op.id = w.assigned_to;

-- ---------- helper cabang untuk laporan ----------
create or replace function public._rpt_branches(p_branch uuid) returns uuid[]
language plpgsql stable security definer set search_path = public as $$
begin
  if p_branch is not null then
    perform require_branch(p_branch);
    return array[p_branch];
  end if;
  if is_global() then return array(select id from branches); end if;
  return array(select branch_id from user_branches where user_id = auth.uid());
end $$;

create or replace function public._acct_sum(p_br uuid[], p_all boolean, p_from date, p_to date, p_codes text[], p_credit_normal boolean)
returns numeric language sql stable security definer set search_path = public as $$
  select coalesce(sum(case when p_credit_normal then jl.credit - jl.debit else jl.debit - jl.credit end), 0)
    from journal_lines jl join journal_entries je on je.id = jl.entry_id
   where jl.account_code = any(p_codes) and je.jdate between p_from and p_to
     and (je.branch_id = any(p_br) or (p_all and je.branch_id is null))
$$;

create or replace function public.rpt_dashboard(p_branch uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[]; v_all boolean; v jsonb; k numeric; ret numeric; disc numeric; ch numeric; hpp numeric; loss numeric; opex numeric;
        inv numeric; hpp30 numeric;
begin
  perform require_perm('dashboard','view');
  v_br := _rpt_branches(p_branch);
  v_all := p_branch is null and is_global();
  k    := _acct_sum(v_br, v_all, p_from, p_to, array['4101','4102'], true);
  ret  := _acct_sum(v_br, v_all, p_from, p_to, array['4104'], false);
  disc := _acct_sum(v_br, v_all, p_from, p_to, array['4103'], false);
  ch   := _acct_sum(v_br, v_all, p_from, p_to, array['6201','6202'], false);
  hpp  := _acct_sum(v_br, v_all, p_from, p_to, array['5101'], false);
  loss := _acct_sum(v_br, v_all, p_from, p_to, array['5102','5103','5104'], false);
  opex := _acct_sum(v_br, v_all, p_from, p_to,
            array(select code from accounts where kind = 'expense' and code not in ('6201','6202')) || array['5105'], false);
  select coalesce(sum(b.qty * p.avg_cost),0) into inv
    from stock_balances b join products p on p.id = b.product_id join stock_locations l on l.id = b.location_id
   where l.kind <> 'scrap' and (l.branch_id = any(v_br) or (v_all and l.branch_id is null));
  hpp30 := _acct_sum(v_br, v_all, today_jkt() - 30, today_jkt(), array['5101'], false);

  v := jsonb_build_object(
    'waterfall', jsonb_build_object('omzet_kotor', k, 'retur', ret, 'diskon', disc, 'biaya_channel', ch,
        'omzet_bersih', k - ret - disc - ch, 'hpp', hpp, 'kerugian_stok', loss,
        'laba_kotor', k - ret - disc - ch - hpp - loss, 'biaya_operasional', opex,
        'laba_bersih', k - ret - disc - ch - hpp - loss - opex),
    'inventory_value', round(inv, 0),
    'turnover_30d', case when inv > 0 then round(hpp30 / inv, 2) else 0 end,
    'by_channel', coalesce((select jsonb_agg(x order by x->>'omzet' desc) from (
        select jsonb_build_object('name', c.name, 'orders', count(*), 'omzet', sum(s.gross_list + s.shipping_charge),
                                  'bersih', sum(s.subtotal - s.discount_amount + s.shipping_charge - s.refund_total - s.channel_fee - s.voucher_seller)) x
          from sales_orders s join sales_channels c on c.id = s.channel_id
         where s.recognized_at is not null and s.status <> 'void' and s.branch_id = any(v_br)
           and (s.recognized_at at time zone 'Asia/Jakarta')::date between p_from and p_to
         group by c.name) z), '[]'),
    'by_branch', coalesce((select jsonb_agg(x) from (
        select jsonb_build_object('name', b.name, 'orders', count(s.id), 'omzet', coalesce(sum(s.gross_list + s.shipping_charge),0),
          'shrinkage', (select coalesce(sum(jl.debit - jl.credit),0) from journal_lines jl join journal_entries je on je.id = jl.entry_id
                         where jl.account_code = '5102' and je.branch_id = b.id and je.jdate > today_jkt() - 30),
          'stock_value', (select coalesce(sum(bb.qty * p.avg_cost),0) from stock_balances bb join products p on p.id = bb.product_id
                           join stock_locations l on l.id = bb.location_id where l.branch_id = b.id and l.kind <> 'scrap')) x
          from branches b left join sales_orders s on s.branch_id = b.id and s.recognized_at is not null and s.status <> 'void'
               and (s.recognized_at at time zone 'Asia/Jakarta')::date between p_from and p_to
         where b.id = any(v_br) group by b.id, b.name) z), '[]'),
    'daily', coalesce((select jsonb_agg(jsonb_build_object('d', d, 'omzet', omzet) order by d) from (
        select (s.recognized_at at time zone 'Asia/Jakarta')::date d, sum(s.gross_list + s.shipping_charge) omzet
          from sales_orders s where s.recognized_at is not null and s.status <> 'void' and s.branch_id = any(v_br)
           and (s.recognized_at at time zone 'Asia/Jakarta')::date between p_from and p_to group by 1) z), '[]'),
    'counts', jsonb_build_object(
        'in_production', (select count(*) from sales_orders where status = 'in_production' and branch_id = any(v_br)),
        'ready_to_ship', (select count(*) from sales_orders where status = 'ready' and branch_id = any(v_br)),
        'payments_pending', (select count(*) from payments where status = 'pending' and branch_id = any(v_br)),
        'returns_waiting', (select count(*) from sales_returns where status = 'expected' and branch_id = any(v_br)),
        'ar_outstanding', (select coalesce(sum(_outstanding(s)),0) from sales_orders s where s.recognized_at is not null
                            and s.status not in ('void','cancelled') and s.branch_id = any(v_br)))
  );
  return v;
end $$;

create or replace function public.rpt_alerts(p_branch uuid) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[]; a jsonb := '[]';
begin
  if not is_active_user() then return a; end if;
  v_br := _rpt_branches(p_branch);

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','stok_minimum','title','Stok di bawah minimum',
          'detail', p.sku || ' ' || p.name || ' di ' || l.name || ': ' || b.qty || ' (min ' || p.min_stock || ')', 'link','#/stock'))
      from stock_balances b join products p on p.id = b.product_id join stock_locations l on l.id = b.location_id
     where l.kind = 'main' and p.min_stock > 0 and b.qty < p.min_stock and l.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','retur_telat','title','Retur belum diterima',
          'detail', r.no || ' (' || c.name || ', resi ' || coalesce(r.return_tracking_no,'-') || ') sudah ' ||
                    (today_jkt() - (r.created_at at time zone 'Asia/Jakarta')::date) || ' hari', 'link','#/returns'))
      from sales_returns r join sales_channels c on c.id = r.channel_id
     where r.status = 'expected' and r.branch_id = any(v_br)
       and r.created_at < now() - make_interval(days => setting_num('return_aging_days')::int)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','transit','title','Transfer menggantung',
          'detail', t.no || ' dari ' || lf.name || ' ke ' || lt.name || ' belum dikonfirmasi ' ||
                    (today_jkt() - (t.sent_at at time zone 'Asia/Jakarta')::date) || ' hari', 'link','#/transfers'))
      from stock_transfers t join stock_locations lf on lf.id = t.from_location_id join stock_locations lt on lt.id = t.to_location_id
     where t.status = 'in_transit' and (lf.branch_id = any(v_br) or lt.branch_id = any(v_br))
       and t.sent_at < now() - make_interval(days => setting_num('transit_aging_days')::int)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','selisih_transfer','title','Berita acara selisih transfer',
          'detail', t.no || ' selisih Rp ' || t.diff_value || ' — tentukan penanggung jawab', 'link','#/transfers'))
      from stock_transfers t join stock_locations lt on lt.id = t.to_location_id
     where t.status = 'received_diff' and lt.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','selisih_kas','title','Selisih kas cabang',
          'detail', c.no || ' selisih Rp ' || c.diff || ' (' || coalesce(c.diff_reason,'') || ')', 'link','#/cash'))
      from cash_sessions c where c.status in ('closed','rejected') and c.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','setoran','title','Setoran kas belum dicatat',
          'detail', c.no || ' ditutup ' || to_char(c.closed_at at time zone 'Asia/Jakarta','DD/MM HH24:MI') || ', belum ada bukti setor', 'link','#/cash'))
      from cash_sessions c where c.status in ('approved','closed') and c.deposit_status in ('none','rejected')
       and c.closed_at < now() - interval '1 day' and c.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','kas_terbuka','title','Sesi kas terbuka terlalu lama',
          'detail', c.no || ' dibuka ' || to_char(c.opened_at at time zone 'Asia/Jakarta','DD/MM HH24:MI'), 'link','#/cash'))
      from cash_sessions c where c.status = 'open' and c.opened_at < now() - interval '18 hours' and c.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','tanpa_bukti','title','Pesanan manual tanpa bukti bayar',
          'detail', s.no || ' (' || c.name || ') ' || s.customer_name || ' — DP Rp ' || s.dp_required, 'link','#/sales?id=' || s.id))
      from sales_orders s join sales_channels c on c.id = s.channel_id
     where c.kind in ('chat','maps','website','b2b','offline') and s.kind = 'order' and s.status in ('in_production','ready')
       and s.dp_required > 0 and not exists(select 1 from payments py where py.so_id = s.id and py.status in ('pending','verified'))
       and s.created_at < now() - make_interval(hours => setting_num('unpaid_order_hours')::int) and s.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','piutang','title','Piutang lewat jatuh tempo',
          'detail', x.no || ' ' || x.customer_name || ' Rp ' || round(_outstanding(x)) || ' telat ' || (today_jkt() - x.due_date) || ' hari', 'link','#/receivables'))
      from sales_orders x join sales_channels c on c.id = x.channel_id
     where x.recognized_at is not null and x.status not in ('void','cancelled') and c.kind <> 'marketplace'
       and x.due_date < today_jkt() and _outstanding(x) > 0.005 and x.branch_id = any(v_br)), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','limit_kredit','title','Pelanggan melewati limit kredit',
          'detail', cu.name || ': piutang Rp ' || round(z.open) || ' / limit Rp ' || cu.credit_limit, 'link','#/receivables'))
      from (select customer_id, sum(_outstanding(s)) open from sales_orders s where s.recognized_at is not null
              and s.status not in ('void','cancelled') and s.customer_id is not null and s.branch_id = any(v_br) group by customer_id) z
      join customers cu on cu.id = z.customer_id where cu.credit_limit > 0 and z.open > cu.credit_limit), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','void_kasir','title','Void/diskon tidak wajar',
          'detail', v.user_name || ' di ' || v.branch_name || ' hari ini: ' || v.voids || ' void, rata-rata diskon ' || coalesce(v.avg_discount_pct,0) || '%', 'link','#/reports'))
      from v_cashier_audit v where v.day = today_jkt() and v.branch_id = any(v_br)
       and (v.voids >= setting_num('void_alert_count') or coalesce(v.avg_discount_pct,0) >= setting_num('discount_alert_pct'))), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','danger','kind','shrinkage','title','Shrinkage cabang melewati ambang',
          'detail', b.name || ': Rp ' || round(z.loss) || ' (' || round(z.loss / nullif(z.inv,0) * 100, 2) || '% nilai stok, 30 hari)', 'link','#/reports'))
      from (select l.branch_id,
                   (select coalesce(sum(jl.debit - jl.credit),0) from journal_lines jl join journal_entries je on je.id = jl.entry_id
                     where jl.account_code = '5102' and je.branch_id = l.branch_id and je.jdate > today_jkt() - 30) loss,
                   sum(bb.qty * p.avg_cost) inv
              from stock_balances bb join stock_locations l on l.id = bb.location_id join products p on p.id = bb.product_id
             where l.kind <> 'scrap' and l.branch_id = any(v_br) group by l.branch_id) z
      join branches b on b.id = z.branch_id
     where z.inv > 0 and z.loss / z.inv * 100 > setting_num('shrinkage_alert_pct')), '[]');

  a := a || coalesce((select jsonb_agg(jsonb_build_object('level','warn','kind','rasio_retur','title','Rasio retur channel naik',
          'detail', z.name || ': ' || z.ret || ' retur dari ' || z.orders || ' pesanan (30 hari)', 'link','#/reports'))
      from (select c.name, (select count(*) from sales_returns r where r.channel_id = c.id and r.created_at > now() - interval '30 days'
                              and r.branch_id = any(v_br)) ret,
                   (select count(*) from sales_orders s where s.channel_id = c.id and s.recognized_at > now() - interval '30 days'
                              and s.branch_id = any(v_br)) orders
              from sales_channels c) z
     where z.orders >= 10 and z.ret::numeric / z.orders * 100 > setting_num('return_rate_alert_pct')), '[]');

  return a;
end $$;

create or replace function public.rpt_pl(p_branch uuid, p_from date, p_to date)
returns table(code text, name text, kind text, amount numeric)
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[]; v_all boolean;
begin
  if not (has_perm('accounting','view') or has_perm('dashboard','view')) then raise exception 'Akses ditolak.'; end if;
  v_br := _rpt_branches(p_branch); v_all := p_branch is null and is_global();
  return query
  select a.code, a.name, a.kind,
         coalesce(sum(case when a.kind = 'revenue' then jl.credit - jl.debit else jl.debit - jl.credit end), 0)::numeric
    from accounts a
    left join (journal_lines jl join journal_entries je on je.id = jl.entry_id
               and je.jdate between p_from and p_to and (je.branch_id = any(v_br) or (v_all and je.branch_id is null)))
      on jl.account_code = a.code
   where a.kind in ('revenue','contra_revenue','cogs','expense')
   group by a.code, a.name, a.kind order by a.code;
end $$;

create or replace function public.rpt_balance(p_branch uuid, p_asof date)
returns table(code text, name text, kind text, balance numeric)
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[]; v_all boolean;
begin
  if not (has_perm('accounting','view') or has_perm('dashboard','view')) then raise exception 'Akses ditolak.'; end if;
  v_br := _rpt_branches(p_branch); v_all := p_branch is null and is_global();
  return query
  with s as (
    select a.code, a.name, a.kind, coalesce(sum(jl.debit - jl.credit),0)::numeric dc
      from accounts a
      left join (journal_lines jl join journal_entries je on je.id = jl.entry_id and je.jdate <= p_asof
                 and (je.branch_id = any(v_br) or (v_all and je.branch_id is null))) on jl.account_code = a.code
     group by a.code, a.name, a.kind)
  select s.code, s.name, s.kind, case when s.kind = 'asset' then s.dc else -s.dc end
    from s where s.kind in ('asset','liability','equity')
  union all
  select '3999', 'Laba (rugi) berjalan', 'equity', -coalesce(sum(s.dc),0) from s where s.kind not in ('asset','liability','equity')
  order by 1;
end $$;

create or replace function public.rpt_cashflow(p_branch uuid, p_from date, p_to date)
returns table(source text, cash_in numeric, cash_out numeric)
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[]; v_all boolean;
begin
  if not (has_perm('accounting','view') or has_perm('dashboard','view')) then raise exception 'Akses ditolak.'; end if;
  v_br := _rpt_branches(p_branch); v_all := p_branch is null and is_global();
  return query
  select case je.source_type when 'PAY' then 'Penerimaan dari pelanggan' when 'STL' then 'Pencairan marketplace'
           when 'SPAY' then 'Pembayaran ke supplier' when 'BYA' then 'Biaya operasional' when 'KAS' then 'Selisih kas'
           when 'SETOR' then 'Setoran kas ke bank (internal)' when 'KLM' then 'Penggantian klaim ekspedisi'
           when 'REVERSAL' then 'Pembalikan (void)' else coalesce(je.source_type,'Lainnya') end,
         coalesce(sum(jl.debit),0)::numeric, coalesce(sum(jl.credit),0)::numeric
    from journal_lines jl join journal_entries je on je.id = jl.entry_id
   where jl.account_code in ('1101','1102') and je.jdate between p_from and p_to
     and (je.branch_id = any(v_br) or (v_all and je.branch_id is null))
   group by 1 order by 1;
end $$;

create or replace function public.rpt_channel(p_branch uuid, p_from date, p_to date) returns jsonb
language plpgsql stable security definer set search_path = public as $$
declare v_br uuid[];
begin
  if not (has_perm('reports','view') or has_perm('dashboard','view')) then raise exception 'Akses ditolak.'; end if;
  v_br := _rpt_branches(p_branch);
  return coalesce((select jsonb_agg(x order by (x->>'omzet')::numeric desc) from (
    select jsonb_build_object('channel', c.name,
      'orders', count(m.id), 'omzet', coalesce(sum(m.gross_list + m.shipping_charge),0),
      'diskon', coalesce(sum(m.discount),0), 'biaya', coalesce(sum(m.channel_fee + m.voucher_seller + m.shipping_cost),0),
      'retur', coalesce(sum(m.refund_total),0), 'hpp', coalesce(sum(m.cogs),0), 'laba', coalesce(sum(m.profit),0),
      'jumlah_retur', (select count(*) from sales_returns r where r.channel_id = c.id and r.branch_id = any(v_br)
                        and (r.created_at at time zone 'Asia/Jakarta')::date between p_from and p_to),
      'margin_pct', case when coalesce(sum(m.net_sales),0) > 0 then round(sum(m.profit) / sum(m.net_sales) * 100, 1) else 0 end) x
    from sales_channels c
    left join v_so_margin m on m.channel_id = c.id and m.branch_id = any(v_br)
         and (m.recognized_at at time zone 'Asia/Jakarta')::date between p_from and p_to
    group by c.id, c.name) z), '[]');
end $$;
-- =====================================================================
--  HAK AKSES DEFAULT PER JABATAN  (V=lihat C=tambah E=ubah A=approve)
--  Bisa diubah Owner dari menu Pengguna & Akses.
-- =====================================================================
insert into public.role_permissions(role, module, can_view, can_create, can_edit, can_approve)
select r, m, position('V' in f) > 0, position('C' in f) > 0, position('E' in f) > 0, position('A' in f) > 0
from (values
 -- Area Manager
 ('area_manager','dashboard','V'),('area_manager','products','V'),('area_manager','bom','V'),('area_manager','branches','V'),
 ('area_manager','channels','V'),('area_manager','customers','VCE'),('area_manager','suppliers','V'),('area_manager','banks','V'),
 ('area_manager','users','V'),('area_manager','audit','V'),('area_manager','settings','V'),('area_manager','purchasing','VA'),
 ('area_manager','grn','V'),('area_manager','sup_invoice','V'),('area_manager','stock','V'),('area_manager','transfer','VA'),
 ('area_manager','opname','VCA'),('area_manager','adjustment','VA'),('area_manager','allocation','V'),('area_manager','production','V'),
 ('area_manager','design','V'),('area_manager','pos','V'),('area_manager','sales','VCEA'),('area_manager','logistics','V'),
 ('area_manager','claims','V'),('area_manager','returns','VA'),('area_manager','return_receive','V'),('area_manager','payments','V'),
 ('area_manager','receivables','V'),('area_manager','cash','VA'),('area_manager','expenses','VA'),('area_manager','payables','V'),
 ('area_manager','bank_recon','V'),('area_manager','settlement','V'),('area_manager','accounting','V'),('area_manager','reports','V'),
 -- Manajer Gudang
 ('warehouse_manager','dashboard','V'),('warehouse_manager','products','VCE'),('warehouse_manager','bom','VCE'),
 ('warehouse_manager','branches','V'),('warehouse_manager','suppliers','VCE'),('warehouse_manager','purchasing','V'),
 ('warehouse_manager','grn','VC'),('warehouse_manager','sup_invoice','V'),('warehouse_manager','stock','V'),
 ('warehouse_manager','transfer','VC'),('warehouse_manager','opname','VCA'),('warehouse_manager','adjustment','VCA'),
 ('warehouse_manager','allocation','VE'),('warehouse_manager','production','V'),('warehouse_manager','logistics','VCE'),
 ('warehouse_manager','returns','V'),('warehouse_manager','reports','V'),
 -- Admin Gudang
 ('inventory_admin','dashboard','V'),('inventory_admin','products','V'),('inventory_admin','stock','V'),('inventory_admin','grn','VC'),
 ('inventory_admin','purchasing','V'),('inventory_admin','transfer','VC'),('inventory_admin','opname','VC'),
 ('inventory_admin','adjustment','VC'),('inventory_admin','allocation','V'),('inventory_admin','logistics','VCE'),
 ('inventory_admin','returns','V'),
 -- Purchasing
 ('purchasing','dashboard','V'),('purchasing','products','V'),('purchasing','suppliers','VCE'),('purchasing','purchasing','VCE'),
 ('purchasing','grn','V'),('purchasing','sup_invoice','VC'),('purchasing','stock','V'),('purchasing','payables','V'),
 ('purchasing','reports','V'),
 -- Produksi
 ('production_head','dashboard','V'),('production_head','products','V'),('production_head','bom','VCE'),('production_head','stock','V'),
 ('production_head','production','VCEA'),('production_head','design','VCE'),('production_head','sales','V'),
 ('production_head','transfer','VC'),('production_head','opname','V'),('production_head','reports','V'),
 ('operator','products','V'),('operator','stock','V'),('operator','production','VE'),('operator','design','V'),
 ('designer','products','V'),('designer','design','VCE'),('designer','production','V'),('designer','sales','V'),
 -- Penjualan
 ('branch_head','dashboard','V'),('branch_head','products','V'),('branch_head','customers','VCE'),('branch_head','stock','V'),
 ('branch_head','transfer','VC'),('branch_head','opname','VC'),('branch_head','adjustment','VCA'),('branch_head','allocation','V'),
 ('branch_head','pos','VC'),('branch_head','sales','VCEA'),('branch_head','production','V'),('branch_head','design','VE'),
 ('branch_head','logistics','VC'),('branch_head','claims','V'),('branch_head','returns','VC'),('branch_head','cash','VCA'),
 ('branch_head','expenses','VC'),('branch_head','payments','VC'),('branch_head','receivables','V'),('branch_head','reports','V'),
 ('cashier','products','V'),('cashier','customers','VC'),('cashier','stock','V'),('cashier','pos','VC'),('cashier','sales','VC'),
 ('cashier','payments','VC'),('cashier','cash','VC'),('cashier','returns','V'),('cashier','logistics','V'),('cashier','design','VE'),
 ('cashier','expenses','VC'),
 ('online_admin','products','V'),('online_admin','customers','VCE'),('online_admin','stock','V'),('online_admin','allocation','VE'),
 ('online_admin','sales','VCE'),('online_admin','design','VCE'),('online_admin','logistics','VC'),('online_admin','claims','VCE'),
 ('online_admin','returns','VC'),('online_admin','payments','VC'),('online_admin','receivables','V'),('online_admin','settlement','V'),
 -- Logistik & QC
 ('logistics','products','V'),('logistics','stock','V'),('logistics','logistics','VCE'),('logistics','claims','VCE'),
 ('logistics','sales','V'),('logistics','transfer','VC'),
 ('qc_return','products','V'),('qc_return','stock','V'),('qc_return','returns','VA'),('qc_return','return_receive','VCE'),
 ('qc_return','production','VA'),('qc_return','sales','V'),
 -- Keuangan
 ('finance_manager','dashboard','V'),('finance_manager','products','V'),('finance_manager','customers','VCEA'),
 ('finance_manager','banks','VCE'),('finance_manager','channels','VCE'),('finance_manager','settings','VE'),('finance_manager','audit','V'),
 ('finance_manager','purchasing','V'),('finance_manager','sup_invoice','VCA'),('finance_manager','stock','V'),
 ('finance_manager','sales','VA'),('finance_manager','returns','V'),('finance_manager','claims','VE'),('finance_manager','payments','VA'),
 ('finance_manager','receivables','VA'),('finance_manager','cash','VA'),('finance_manager','expenses','VA'),
 ('finance_manager','payables','VCEA'),('finance_manager','bank_recon','VCE'),('finance_manager','settlement','VCE'),
 ('finance_manager','accounting','VCE'),('finance_manager','reports','V'),
 ('accountant','dashboard','V'),('accountant','sales','V'),('accountant','stock','V'),('accountant','purchasing','V'),
 ('accountant','sup_invoice','VC'),('accountant','payments','V'),('accountant','receivables','V'),('accountant','cash','V'),
 ('accountant','expenses','VC'),('accountant','payables','V'),('accountant','bank_recon','VCE'),('accountant','settlement','VCE'),
 ('accountant','accounting','V'),('accountant','reports','V'),
 ('payment_verifier','payments','VA'),('payment_verifier','bank_recon','VCE'),('payment_verifier','receivables','V'),
 ('payment_verifier','cash','V'),('payment_verifier','sales','V')
) v(r, m, f)
on conflict (role, module) do nothing;

-- perubahan limit kredit hanya oleh keuangan/owner
create or replace function public.trg_customer_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if current_user in ('authenticated','anon') and not (has_perm('customers','approve'))
     and (new.credit_limit is distinct from coalesce(old.credit_limit, 0) or new.terms_days is distinct from coalesce(old.terms_days, 0)
          or new.blocked is distinct from coalesce(old.blocked, false)) then
    raise exception 'Limit kredit, termin, dan blokir pelanggan hanya bisa diubah Keuangan / Owner.';
  end if;
  return new;
end $$;
drop trigger if exists customer_guard on public.customers;
create trigger customer_guard before insert or update on public.customers
  for each row execute function public.trg_customer_guard();

-- =====================================================================
--  ROW LEVEL SECURITY
-- =====================================================================
do $$ declare t text; begin
  foreach t in array array[
    'roles','sod_conflicts','branches','stock_locations','profiles','user_roles','user_branches','role_permissions','app_settings',
    'doc_sequences','audit_log','products','bom_lines','cost_history','serial_units','sales_channels','customers','suppliers',
    'bank_accounts','adjustment_reasons','return_reasons','accounts','expense_categories',
    'stock_ledger','stock_balances','channel_allocations','stock_transfers','transfer_lines','stock_opnames','opname_lines',
    'stock_adjustments','adjustment_lines','purchase_orders','po_lines','goods_receipts','gr_lines','supplier_invoices',
    'purchase_returns','purchase_return_lines','sales_orders','so_lines','cash_sessions','channel_settlements','bank_transactions',
    'payments','work_orders','design_approvals','wo_consumptions','wo_scraps','offcuts','delivery_orders','courier_claims',
    'sales_returns','return_lines','expenses','journal_entries','journal_lines'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists sel on public.%I', t);
    execute format('drop policy if exists ins on public.%I', t);
    execute format('drop policy if exists upd on public.%I', t);
    execute format('drop policy if exists del on public.%I', t);
  end loop;
  -- data referensi: dapat dibaca semua pengguna aktif
  foreach t in array array['roles','sod_conflicts','branches','stock_locations','profiles','user_roles','user_branches',
    'role_permissions','app_settings','products','bom_lines','cost_history','serial_units','sales_channels','customers',
    'suppliers','bank_accounts','adjustment_reasons','return_reasons','accounts','expense_categories'] loop
    execute format('create policy sel on public.%I for select to authenticated using (public.is_active_user())', t);
  end loop;
end $$;

-- penulisan master data langsung (tetap diaudit)
create policy ins on public.branches for insert to authenticated with check (has_perm('branches','create'));
create policy upd on public.branches for update to authenticated using (has_perm('branches','edit'));
create policy ins on public.stock_locations for insert to authenticated with check (has_perm('branches','create'));
create policy upd on public.stock_locations for update to authenticated using (has_perm('branches','edit'));
create policy ins on public.products for insert to authenticated with check (has_perm('products','create'));
create policy upd on public.products for update to authenticated using (has_perm('products','edit'));
create policy ins on public.bom_lines for insert to authenticated with check (has_perm('bom','edit'));
create policy upd on public.bom_lines for update to authenticated using (has_perm('bom','edit'));
create policy del on public.bom_lines for delete to authenticated using (has_perm('bom','edit'));
create policy ins on public.sales_channels for insert to authenticated with check (has_perm('channels','create'));
create policy upd on public.sales_channels for update to authenticated using (has_perm('channels','edit'));
create policy ins on public.customers for insert to authenticated with check (has_perm('customers','create'));
create policy upd on public.customers for update to authenticated using (has_perm('customers','edit'));
create policy ins on public.suppliers for insert to authenticated with check (has_perm('suppliers','create'));
create policy upd on public.suppliers for update to authenticated using (has_perm('suppliers','edit'));
create policy ins on public.bank_accounts for insert to authenticated with check (has_perm('banks','create'));
create policy upd on public.bank_accounts for update to authenticated using (has_perm('banks','edit'));
create policy upd on public.app_settings for update to authenticated using (has_perm('settings','edit'));
create policy ins on public.role_permissions for insert to authenticated with check (has_role('owner'));
create policy upd on public.role_permissions for update to authenticated using (has_role('owner'));
create policy upd on public.roles for update to authenticated using (has_role('owner'));
create policy sel on public.audit_log for select to authenticated using (has_perm('audit','view'));

-- data transaksi: hanya BACA sesuai modul & cabang. Semua penulisan lewat RPC.
create policy sel on public.stock_balances for select to authenticated using (has_perm('stock','view') and can_loc(location_id));
create policy sel on public.stock_ledger for select to authenticated using (has_perm('stock','view') and can_loc(location_id));
create policy sel on public.channel_allocations for select to authenticated using (has_perm('stock','view') and can_loc(location_id));

create policy sel on public.stock_transfers for select to authenticated
  using (has_perm('transfer','view') and (can_loc(from_location_id) or can_loc(to_location_id)));
create policy sel on public.transfer_lines for select to authenticated
  using (exists(select 1 from stock_transfers t where t.id = transfer_id));
create policy sel on public.stock_opnames for select to authenticated using (has_perm('opname','view') and can_loc(location_id));
create policy sel on public.opname_lines for select to authenticated using (exists(select 1 from stock_opnames o where o.id = opname_id));
create policy sel on public.stock_adjustments for select to authenticated using (has_perm('adjustment','view') and can_loc(location_id));
create policy sel on public.adjustment_lines for select to authenticated using (exists(select 1 from stock_adjustments a where a.id = adjustment_id));

create policy sel on public.purchase_orders for select to authenticated
  using ((has_perm('purchasing','view') or has_perm('grn','view') or has_perm('sup_invoice','view') or has_perm('payables','view'))
         and can_loc(location_id));
create policy sel on public.po_lines for select to authenticated using (exists(select 1 from purchase_orders p where p.id = po_id));
create policy sel on public.goods_receipts for select to authenticated
  using ((has_perm('grn','view') or has_perm('purchasing','view') or has_perm('sup_invoice','view')) and can_loc(location_id));
create policy sel on public.gr_lines for select to authenticated using (exists(select 1 from goods_receipts g where g.id = gr_id));
create policy sel on public.supplier_invoices for select to authenticated
  using (has_perm('sup_invoice','view') or has_perm('payables','view') or has_perm('purchasing','view'));
create policy sel on public.purchase_returns for select to authenticated using (has_perm('purchasing','view') and can_loc(location_id));
create policy sel on public.purchase_return_lines for select to authenticated using (exists(select 1 from purchase_returns r where r.id = return_id));

create policy sel on public.sales_orders for select to authenticated
  using ((has_perm('sales','view') or has_perm('pos','view') or has_perm('logistics','view') or has_perm('production','view')
          or has_perm('design','view') or has_perm('payments','view') or has_perm('receivables','view') or has_perm('returns','view')
          or has_perm('return_receive','view')) and can_branch(branch_id));
create policy sel on public.so_lines for select to authenticated using (exists(select 1 from sales_orders s where s.id = so_id));
create policy sel on public.payments for select to authenticated
  using ((has_perm('payments','view') or has_perm('receivables','view') or has_perm('sales','view') or has_perm('pos','view')
          or has_perm('cash','view')) and can_branch(branch_id));
create policy sel on public.cash_sessions for select to authenticated
  using ((has_perm('cash','view') or has_perm('payments','view')) and can_branch(branch_id));
create policy sel on public.channel_settlements for select to authenticated
  using (has_perm('settlement','view') or has_perm('accounting','view'));
create policy sel on public.bank_transactions for select to authenticated
  using (has_perm('bank_recon','view') or has_perm('payments','approve'));

create policy sel on public.work_orders for select to authenticated
  using ((has_perm('production','view') or has_perm('design','view') or has_perm('sales','view')) and can_loc(location_id));
create policy sel on public.design_approvals for select to authenticated
  using ((has_perm('design','view') or has_perm('production','view') or has_perm('sales','view'))
         and exists(select 1 from sales_orders s where s.id = so_id));
create policy sel on public.wo_consumptions for select to authenticated using (exists(select 1 from work_orders w where w.id = wo_id));
create policy sel on public.wo_scraps for select to authenticated using (exists(select 1 from work_orders w where w.id = wo_id));
create policy sel on public.offcuts for select to authenticated using (has_perm('production','view') and can_loc(location_id));

create policy sel on public.delivery_orders for select to authenticated
  using ((has_perm('logistics','view') or has_perm('sales','view') or has_perm('claims','view')) and can_loc(location_id));
create policy sel on public.courier_claims for select to authenticated
  using (has_perm('claims','view') and exists(select 1 from delivery_orders d where d.id = do_id));
create policy sel on public.sales_returns for select to authenticated
  using ((has_perm('returns','view') or has_perm('return_receive','view')) and can_branch(branch_id));
create policy sel on public.return_lines for select to authenticated using (exists(select 1 from sales_returns r where r.id = return_id));
create policy sel on public.expenses for select to authenticated using (has_perm('expenses','view') and can_branch(branch_id));
create policy sel on public.journal_entries for select to authenticated using (has_perm('accounting','view'));
create policy sel on public.journal_lines for select to authenticated using (has_perm('accounting','view'));

-- =====================================================================
--  STORAGE: bukti bayar, foto packing, foto unboxing, mockup
--  (tidak ada izin ubah/hapus → bukti tidak bisa diganti)
-- =====================================================================
insert into storage.buckets(id, name, public) values ('erp-files', 'erp-files', false) on conflict (id) do nothing;
drop policy if exists "erp files insert" on storage.objects;
drop policy if exists "erp files select" on storage.objects;
create policy "erp files insert" on storage.objects for insert to authenticated
  with check (bucket_id = 'erp-files' and public.is_active_user());
create policy "erp files select" on storage.objects for select to authenticated
  using (bucket_id = 'erp-files' and public.is_active_user());

-- =====================================================================
--  IZIN EKSEKUSI FUNGSI
--  Fungsi internal (berawalan _ dan mesin) TIDAK bisa dipanggil aplikasi.
-- =====================================================================
revoke execute on all functions in schema public from public, anon, authenticated;

grant execute on function
  public.today_jkt(), public.is_active_user(), public.my_roles(), public.has_role(text), public.is_global(),
  public.can_branch(uuid), public.can_loc(uuid), public.has_perm(text,text), public.my_discount_limit(),
  public._outstanding(public.sales_orders), public.bom_cost(uuid), public.cash_expected(uuid), public.me(),
  -- pembelian
  public.po_save(jsonb), public.po_submit(uuid), public.po_decide(uuid,boolean,text), public.po_close(uuid,text),
  public.grn_post(uuid,jsonb,text), public.sup_invoice_create(jsonb), public.sup_invoice_decide(uuid,boolean,text),
  public.sup_invoice_pay(uuid,uuid,text), public.purchase_return_post(jsonb),
  -- persediaan
  public.transfer_send(jsonb), public.transfer_receive(uuid,jsonb,text), public.transfer_resolve(uuid,text,text),
  public.opname_create(uuid,text,int,text), public.opname_count(uuid,jsonb), public.opname_submit(uuid),
  public.opname_decide(uuid,boolean,text), public.adjustment_create(jsonb), public.adjustment_decide(uuid,boolean,text),
  public.allocation_set(uuid,uuid,uuid,numeric), public.recalc_costs(),
  -- penjualan
  public.so_save(jsonb), public.so_confirm(uuid), public.so_approve(uuid,text,boolean,text),
  public.pos_checkout(jsonb), public.pos_complete(uuid,jsonb), public.so_void_request(uuid,text),
  public.so_void_decide(uuid,boolean,text), public.mp_import(uuid,uuid,jsonb),
  -- produksi
  public.design_upload(uuid,text,text), public.design_decide(uuid,boolean,text,text), public.wo_assign(uuid,uuid,date),
  public.wo_start(uuid), public.wo_consume(uuid,jsonb), public.wo_scrap(jsonb), public.wo_offcut(jsonb),
  public.offcut_set_status(uuid,text,uuid,text), public.wo_finish(uuid), public.wo_qc(uuid,boolean,text),
  -- logistik & retur
  public.do_create(uuid), public.do_pack(uuid,text,jsonb), public.do_ship(uuid,text,text,numeric), public.do_deliver(uuid,text),
  public.claim_create(jsonb), public.claim_update(uuid,text,numeric,text),
  public.return_create(jsonb), public.return_receive(uuid,jsonb,text,text), public.return_cancel(uuid,text),
  public.return_dispose(uuid,text,text,text,text),
  -- keuangan
  public.payment_create(jsonb), public.payment_verify(uuid,boolean,text,uuid), public.cash_open(uuid,numeric),
  public.cash_close(uuid,numeric,text), public.cash_decide(uuid,boolean,text), public.cash_deposit(uuid,numeric,uuid,text),
  public.cash_deposit_verify(uuid,boolean,text), public.expense_create(jsonb), public.expense_decide(uuid,boolean,text),
  public.bank_import(uuid,jsonb), public.bank_match(uuid,uuid,text), public.settlement_preview(uuid,date,date),
  public.settlement_record(jsonb), public.user_admin(jsonb),
  -- laporan
  public.rpt_dashboard(uuid,date,date), public.rpt_alerts(uuid), public.rpt_pl(uuid,date,date), public.rpt_balance(uuid,date),
  public.rpt_cashflow(uuid,date,date), public.rpt_channel(uuid,date,date)
to authenticated;

-- Pastikan hak dasar sesuai (RLS di atas yang menentukan baris mana yang terlihat).
grant usage on schema public to anon, authenticated;
grant select on all tables in schema public to authenticated;
grant insert, update on public.products, public.bom_lines, public.branches, public.stock_locations,
  public.sales_channels, public.customers, public.suppliers, public.bank_accounts, public.app_settings,
  public.role_permissions, public.roles to authenticated;
grant delete on public.bom_lines to authenticated;

-- tabel transaksi tidak boleh ditulis langsung dari aplikasi
revoke insert, update, delete on
  public.stock_ledger, public.stock_balances, public.channel_allocations, public.stock_transfers, public.transfer_lines,
  public.stock_opnames, public.opname_lines, public.stock_adjustments, public.adjustment_lines, public.purchase_orders,
  public.po_lines, public.goods_receipts, public.gr_lines, public.supplier_invoices, public.purchase_returns,
  public.purchase_return_lines, public.sales_orders, public.so_lines, public.cash_sessions, public.channel_settlements,
  public.bank_transactions, public.payments, public.work_orders, public.design_approvals, public.wo_consumptions,
  public.wo_scraps, public.offcuts, public.delivery_orders, public.courier_claims, public.sales_returns, public.return_lines,
  public.expenses, public.journal_entries, public.journal_lines, public.audit_log, public.doc_sequences,
  public.profiles, public.user_roles, public.user_branches, public.serial_units, public.cost_history
from anon, authenticated;
revoke all on all tables in schema public from anon;

-- =====================================================================
--  SELESAI. Langkah berikut: buat user pertama di Authentication,
--  lalu jadikan Owner (lihat README).
-- =====================================================================
